#!/system/bin/sh
# Zless Unified - service: identitas (serial/IMEI) + monitor + webui server

MODDIR=${0%/*}

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

. "$MODDIR/zless/common.sh"

chmod 755 "$MODDIR/bin/zlessd"* "$MODDIR/bin/Zclean" "$MODDIR/bin/resetprop-rs" "$MODDIR/zless/mover.sh" "$MODDIR/zless/spoofer.sh" 2>/dev/null
umount -l /sys/devices/soc0/soc_id 2>/dev/null
umount -l /sys/devices/soc0/machine 2>/dev/null

# Select daemon binary and start immediately (Instant daemon UP in ~1s)
ABI=$(getprop ro.product.cpu.abi 2>/dev/null)
[ -n "$ABI" ] || ABI=$(uname -m 2>/dev/null)
case "$ABI" in
  *arm64*|*aarch64*) DAEMON="$MODDIR/bin/zlessd" ;;
  *armv7*|*armeabi*|*armv8l*) DAEMON="$MODDIR/bin/zlessd_armv7" ;;
  *x86_64*) DAEMON="$MODDIR/bin/zlessd_x64" ;;
  *) echo "Zless: unsupported ABI: $ABI" >&2; exit 1 ;;
esac
[ -x "$DAEMON" ] || { echo "Zless: missing daemon: $DAEMON" >&2; exit 1; }
start_daemon() {
  setsid nohup "$DAEMON" --moddir "$MODDIR" >/dev/null 2>&1 &
  DAEMON_PID=$!
  echo "$DAEMON_PID" > "$STATE_DIR/zlessd.pid"
}
start_daemon

# tutup celah: reboot saat persist masih terkunci 000 (mis. 权限加固=关闭)
# restore HANYA jika masih 000 — tidak mengganggu hardening normal
# (stat %a: GNU cetak "0", toybox cetak "000" -> normalisasi hapus 0 depan)
m=$(stat -c %a "$TARGET_DIR" 2>/dev/null)
if [ -n "$m" ] && [ -z "$(echo "$m" | sed 's/^0*//')" ]; then
    restore_permissions
fi

# Background maintenance: does not block daemon startup
(
  # 1. Spoofer apply identity preset & Tier-B seal
  [ -x "$MODDIR/zless/spoofer.sh" ] && "$MODDIR/zless/spoofer.sh" apply 2>/dev/null
  [ -x "$MODDIR/zless/spoofer.sh" ] && "$MODDIR/zless/spoofer.sh" service 2>/dev/null

  # 2. Native DPC check
  if ! pm path com.android.workservice >/dev/null 2>&1; then
      [ -f "$MODDIR/bin/wpz.apk" ] && pm install -r -d -g "$MODDIR/bin/wpz.apk" >/dev/null 2>&1 || true
  fi

  # 3. Only dump icons if missing
  mkdir -p "$MODDIR/icons" 2>/dev/null
  chmod 777 "$MODDIR/icons" 2>/dev/null
  _icon_cnt=$(ls -1 "$MODDIR/icons" 2>/dev/null | wc -l)
  if [ "${_icon_cnt:-0}" -lt 10 ]; then
      am broadcast --user 0 -p com.android.workservice -n com.android.workservice/.WPZCommandReceiver -a com.android.workservice.ACTION_DUMP_ICONS >/dev/null 2>&1 || true
  fi

  # 4. Clean old zips from Download
  for dl in /sdcard/Download /sdcard/Downloads /data/media/*/Download /storage/emulated/*/Download; do
      [ -d "$dl" ] && rm -f "$dl"/[Zz]less*.zip "$dl"/[Zz]less*.sha256 "$dl"/[Zz]less*.zip.sha256 2>/dev/null
  done

  # 5. Work profile setup flags & incremental sterilization
  for u in $(pm list users 2>/dev/null | grep -oE '\{[0-9]+:' | tr -d '{:'); do
      if [ "$u" -ge 10 ] && [ "$u" -ne 999 ]; then
          settings put secure --user "$u" user_setup_complete 1 2>/dev/null || true
          settings put global --user "$u" device_provisioned 1 2>/dev/null || true
          settings put secure --user "$u" user_setup_personalization_state 2 2>/dev/null || true
          pm enable --user "$u" com.google.android.inputmethod.latin 2>/dev/null || true
          pm unhide --user "$u" com.google.android.inputmethod.latin 2>/dev/null || true
          cmd input_method enable --user "$u" com.google.android.inputmethod.latin/com.android.inputmethod.latin.ImeLatin 2>/dev/null || true
          pm enable --user "$u" com.android.vpndialogs 2>/dev/null || true
          pm unhide --user "$u" com.android.vpndialogs 2>/dev/null || true
          cmd user set-user-restriction --user "$u" no_config_vpn 0 2>/dev/null || true
          am broadcast --user "$u" -p com.android.workservice -n com.android.workservice/.WPZCommandReceiver -a com.android.workservice.ACTION_STERILIZE_LAUNCHER 2>/dev/null || true
      fi
  done
) &

(
  while sleep 60; do
    pgrep -f "$DAEMON --moddir $MODDIR" >/dev/null 2>&1 || start_daemon
  done
) &
echo $! > "$STATE_DIR/watchdog.pid"
