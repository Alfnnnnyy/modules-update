#!/system/bin/sh
# Zless Unified - uninstall: hentikan daemon + pulihkan permission persist

MODDIR=${0%/*}

# Stop the supervised native daemon before module files disappear.
[ -f "$MODDIR/zless/state/watchdog.pid" ] && kill "$(cat "$MODDIR/zless/state/watchdog.pid" 2>/dev/null)" 2>/dev/null
pkill -f "$MODDIR/bin/zlessd.*--moddir $MODDIR" 2>/dev/null
sleep 1
pkill -f "$MODDIR/bin/zlessd.*--moddir $MODDIR" 2>/dev/null
pkill -f "$MODDIR/zless/monitor.sh" 2>/dev/null
pkill -f "$MODDIR/zless/webui_server.sh" 2>/dev/null
sleep 1

. "$MODDIR/zless/common.sh"
restore_permissions
umount -l /proc/cpuinfo 2>/dev/null || umount /proc/cpuinfo 2>/dev/null

echo "Zless Unified dihapus. Permission persist dipulihkan."
