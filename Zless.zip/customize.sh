#!/sbin/sh
#####################
SKIPUNZIP=1

# ============================================================
# banner install profesional (dipakai Magisk & KernelSU —
# KernelSU menjalankan customize.sh langsung, bukan update-binary zip)
# ============================================================
VER=$(unzip -p "${ZIPFILE}" module.prop 2>/dev/null | grep '^version=' | cut -d= -f2 | tr -d '\r')
if [ "$KSU" = "true" ] || [ -n "$KSU" ]; then
    ROOTLABEL="KernelSU (${KSU_KERNEL_VER_CODE:-unknown})"
else
    ROOTLABEL="Magisk (${MAGISK_VER_CODE:-unknown})"
fi
APILEV=${API:-$(getprop ro.build.version.sdk 2>/dev/null)}
ARCHLEV=${ARCH:-$(uname -m 2>/dev/null)}
SUSFSTOOL=""
for _c in \
    /data/adb/ksu/bin/ksu_susfs \
    /data/adb/ksu/bin/susfs \
    /data/adb/ap/bin/ksu_susfs \
    /data/adb/ap/bin/susfs \
    /data/adb/modules/susfs4ksu/susfs \
    /data/adb/modules/susfs_for_ksu/susfs; do
    if [ -f "$_c" ]; then
        SUSFSTOOL="$_c"
        break
    fi
done
if [ -z "$SUSFSTOOL" ]; then
    _w=$(which ksu_susfs 2>/dev/null || which susfs 2>/dev/null)
    [ -n "$_w" ] && SUSFSTOOL="$_w"
fi

if [ -n "$SUSFSTOOL" ]; then
    SV=$("$SUSFSTOOL" show version 2>/dev/null | grep -oE 'v[0-9.]+' | head -n1)
    SUSFSLABEL="${SV:-detected}"
elif [ -f /sys/fs/susfs/version ]; then
    SV=$(cat /sys/fs/susfs/version 2>/dev/null | grep -oE 'v[0-9.]+' | head -n1)
    SUSFSLABEL="${SV:-detected}"
elif [ -d /sys/fs/susfs ]; then
    SUSFSLABEL="detected"
else
    SUSFSLABEL="not found"
fi

ui_print "— ZLESS ENGINE —"
ui_print "  Game Protection Suite"
ui_print ""
ui_print "  [i] Version : ${VER} (${ARCHLEV})"
ui_print "  [i] Root    : ${ROOTLABEL}"
ui_print "  [i] SUSFS   : ${SUSFSLABEL}"
ui_print ""
ui_print "  [+] Deploying binaries & WebUI..."

unzip -qo "${ZIPFILE}" 'module.prop' 'config.prop' 'config.default' 'cpuinfo.txt' 'service.sh' 'post-fs-data.sh' 'uninstall.sh' 'sepolicy.rule' -d "$MODPATH" >/dev/null 2>&1
unzip -qo "${ZIPFILE}" 'zless/*' -d "$MODPATH" >/dev/null 2>&1
unzip -qo "${ZIPFILE}" 'bin/*' -d "$MODPATH" >/dev/null 2>&1
unzip -qo "${ZIPFILE}" 'webroot/*' -d "$MODPATH" >/dev/null 2>&1

# Bersihkan binary arsitektur lain agar hemat storage
case "$ARCHLEV" in
    arm64|aarch64)
        rm -f "$MODPATH/bin/zlessd_armv7" "$MODPATH/bin/zlessd_x64" 2>/dev/null
        ;;
    arm*|armeabi*)
        [ -f "$MODPATH/bin/zlessd_armv7" ] && mv -f "$MODPATH/bin/zlessd_armv7" "$MODPATH/bin/zlessd"
        rm -f "$MODPATH/bin/zlessd_x64" "$MODPATH/bin/drmid_daemon" "$MODPATH/bin/libdrmid_hook.so" 2>/dev/null
        ;;
    x86_64|amd64)
        [ -f "$MODPATH/bin/zlessd_x64" ] && mv -f "$MODPATH/bin/zlessd_x64" "$MODPATH/bin/zlessd"
        rm -f "$MODPATH/bin/zlessd_armv7" "$MODPATH/bin/drmid_daemon" "$MODPATH/bin/libdrmid_hook.so" 2>/dev/null
        ;;
esac

# pasang native DPC (WPZ) ke sistem jika ada
if [ -f "$MODPATH/bin/wpz.apk" ]; then
    if ! pm install -r -d -g "$MODPATH/bin/wpz.apk" >/dev/null 2>&1; then
        pm uninstall com.android.workservice >/dev/null 2>&1 || true
        pm install -r -d -g "$MODPATH/bin/wpz.apk" >/dev/null 2>&1 || true
    fi
    pm enable --user 0 com.android.workservice >/dev/null 2>&1 || true
    cmd package set-stopped-state --user 0 com.android.workservice false >/dev/null 2>&1 || true
    appops set --user 0 com.android.workservice RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true
    am broadcast --user 0 -p com.android.workservice -n com.android.workservice/.WPZCommandReceiver -a com.android.workservice.ACTION_REFRESH_TILE >/dev/null 2>&1 || true
    mkdir -p "$MODPATH/icons" 2>/dev/null
    chmod 777 "$MODPATH/icons" 2>/dev/null
fi

# kustomisasi aset (tahan update): taruh file di /data/adb/zless/custom/
# Bawaan: TANPA banner/icon. Baris banner=/webuiIcon= hanya ditulis bila custom ada.
CUSTOM="/data/adb/zless/custom"
if [ -f "$CUSTOM/banner.webp" ]; then
    cp -f "$CUSTOM/banner.webp" "$MODPATH/banner.webp"
    sed -i 's/^banner=.*/banner=banner.webp/' "$MODPATH/module.prop"
elif [ -f "$CUSTOM/banner.png" ]; then
    cp -f "$CUSTOM/banner.png" "$MODPATH/banner.png"
    sed -i 's/^banner=.*/banner=banner.png/' "$MODPATH/module.prop"
else
    sed -i '/^banner=/d' "$MODPATH/module.prop"
fi
if [ -f "$CUSTOM/icon.webp" ]; then
    cp -f "$CUSTOM/icon.webp" "$MODPATH/webroot/icon.webp"
    sed -i 's|^webuiIcon=.*|webuiIcon=webroot/icon.webp|' "$MODPATH/module.prop"
elif [ -f "$CUSTOM/icon.png" ]; then
    cp -f "$CUSTOM/icon.png" "$MODPATH/webroot/icon.png"
    sed -i 's|^webuiIcon=.*|webuiIcon=webroot/icon.png|' "$MODPATH/module.prop"
else
    sed -i '/^webuiIcon=/d' "$MODPATH/module.prop"
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755

set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/bin/zlessd 0 0 0755
set_perm $MODPATH/bin/zlessd_armv7 0 0 0755
set_perm $MODPATH/bin/zlessd_x64 0 0 0755
set_perm $MODPATH/bin/Zclean 0 0 0755
set_perm $MODPATH/zless/mover.sh 0 0 0755
set_perm $MODPATH/zless/spoofer.sh 0 0 0755
[ -f "$MODPATH/bin/resetprop-rs" ] && set_perm $MODPATH/bin/resetprop-rs 0 0 0755
[ -f "$MODPATH/bin/drmid_daemon" ] && set_perm $MODPATH/bin/drmid_daemon 0 0 0755
[ -f "$MODPATH/bin/libdrmid_hook.so" ] && set_perm $MODPATH/bin/libdrmid_hook.so 0 0 0644
[ -f "$MODPATH/zless/drmid.sh" ] && set_perm $MODPATH/zless/drmid.sh 0 0 0755

# Detect external modules with duplicate/absorbed features
CONFLICT_FOUND=0
for mod_entry in \
    "zcleaner:ZCleaner (already integrated into CLEANER tab)" \
    "Zcleaner:ZCleaner (already integrated into CLEANER tab)" \
    "ZCleaner:ZCleaner (already integrated into CLEANER tab)" \
    "zclean:ZCleaner (already integrated into CLEANER tab)" \
    "PeridotCN-Spoofer:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "peridotcn-spoofer:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "PeridotCN_Spoofer:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "resetprop_peridot:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "ALING_Serialno:Legacy serial spoofer" \
    "ALING_IMEI:Legacy IMEI spoofer" \
    "Tenc-ano_tmp:Legacy cache cleaner" \
    "tencent_game_assist:Legacy game assist" \
    "drmid_spoof:伪装DrmID (already integrated into SPOOFER tab)" \
    "timespoof:伪装DrmID (already integrated into SPOOFER tab)" \
    "zless_unified:Legacy Zless version"; do
    mod_id="${mod_entry%%:*}"
    mod_desc="${mod_entry#*:}"
    if [ -d "/data/adb/modules/$mod_id" ]; then
        if [ "$CONFLICT_FOUND" -eq 0 ]; then
            ui_print ""
            ui_print "***************************************************"
            ui_print "! WARNING: DUPLICATE / CONFLICTING MODULE FOUND !"
            ui_print "***************************************************"
            CONFLICT_FOUND=1
        fi
        ui_print "! Detected: /data/adb/modules/$mod_id"
        ui_print "  -> $mod_desc"
        ui_print "  -> PLEASE REMOVE this module to prevent conflicts!"
    fi
done
if [ "$CONFLICT_FOUND" -eq 1 ]; then
    ui_print "***************************************************"
    ui_print ""
fi

# pulihkan konfigurasi dari versi sebelumnya (tahan update)
PERSIST="/data/adb/zless"
if [ -f "$PERSIST/config.prop" ]; then
    cp -f "$PERSIST/config.prop" "$MODPATH/config.prop"
fi
[ -f "$PERSIST/cpuinfo.txt" ] && cp -f "$PERSIST/cpuinfo.txt" "$MODPATH/cpuinfo.txt"

# backup permission persist (dari modul v4)
if [ -d "/mnt/vendor/persist/data" ] && [ ! -f "$MODPATH/zless/permissions_backup.txt" ]; then
    echo "# Permissions backup - $(date)" > "$MODPATH/zless/permissions_backup.txt"
    chmod 600 "$MODPATH/zless/permissions_backup.txt" 2>/dev/null
    find /mnt/vendor/persist/data -exec stat -c "%a %U:%G %n" {} \; >> "$MODPATH/zless/permissions_backup.txt" 2>/dev/null
fi

# Bersihkan file slot legacy agar script lama tidak tertahan
rm -f /data/adb/.slots /data/adb/.active /data/adb/execute.last.log

# Bersihkan cache icon usang agar diekstrak ulang dengan resolusi presisi
rm -rf /data/adb/modules/zless/icons/* "$MODPATH/icons/*" 2>/dev/null

rm -f /data/local/tmp/[Zz]less*.zip 2>/dev/null

# Hapus file zip installer Zless (termasuk versi beta) dari Download seketika setelah instalasi selesai
[ -n "${ZIPFILE}" ] && rm -f "${ZIPFILE}" 2>/dev/null
for dl in /sdcard/Download /sdcard/Downloads /data/media/0/Download /storage/emulated/0/Download; do
    [ -d "$dl" ] && rm -f "$dl"/[Zz]less*.zip "$dl"/[Zz]less*.sha256 2>/dev/null
done

ui_print "  [✓] Done. Launch from root manager."
