#!/sbin/sh
#####################
SKIPUNZIP=1

# ============================================================
# banner install profesional (dipakai Magisk & KernelSU —
# KernelSU menjalankan customize.sh langsung, bukan update-binary zip)
# ============================================================
VER=$(unzip -p "${ZIPFILE}" module.prop 2>/dev/null | grep '^version=' | cut -d= -f2 | tr -d '\r')
if [ "$KSU" = "true" ] || [ -n "$KSU" ]; then
    ROOTLABEL="KernelSU (${KSU_KERNEL_VER_CODE:-unknown})"
else
    ROOTLABEL="Magisk (${MAGISK_VER_CODE:-unknown})"
fi
APILEV=${API:-$(getprop ro.build.version.sdk 2>/dev/null)}
ARCHLEV=${ARCH:-$(uname -m 2>/dev/null)}
if [ -f /data/adb/ksu/bin/susfs ]; then
    SV=$(/data/adb/ksu/bin/susfs show version 2>/dev/null | grep -oE 'v[0-9.]+' | head -n1)
    SUSFSLABEL="${SV:-detected}"
else
    SUSFSLABEL="not found"
fi

ui_print "****************************************"
ui_print "              Z L E S S                 "
ui_print "   Game Protection & Execute Runner     "
ui_print "****************************************"
ui_print "- Version : ${VER}"
ui_print "- Root    : ${ROOTLABEL}"
ui_print "- Device  : Android ${APILEV} (${ARCHLEV})"
ui_print "- SUSFS   : ${SUSFSLABEL}"
ui_print ""
ui_print "- Zless Unified: memasang file..."

unzip -o "${ZIPFILE}" 'module.prop' 'config.prop' 'config.default' 'cpuinfo.txt' 'service.sh' 'post-fs-data.sh' 'uninstall.sh' -d $MODPATH >&2
unzip -o "${ZIPFILE}" 'zless/*' -d $MODPATH
unzip -o "${ZIPFILE}" 'bin/*' -d $MODPATH >&2
unzip -o "${ZIPFILE}" 'webroot/*' -d $MODPATH >&2

# pasang native DPC (WPZ) ke sistem jika ada
if [ -f "$MODPATH/bin/wpz.apk" ]; then
    ui_print "- Memasang Native DPC Subsystem (WPZ)..."
    if ! pm install -r -d -g "$MODPATH/bin/wpz.apk" >/dev/null 2>&1; then
        pm uninstall com.android.workservice >/dev/null 2>&1 || true
        pm install -r -d -g "$MODPATH/bin/wpz.apk" >/dev/null 2>&1 || true
    fi
    mkdir -p "$MODPATH/icons" 2>/dev/null
    chmod 777 "$MODPATH/icons" 2>/dev/null
    am broadcast --user 0 -p com.android.workservice -n com.android.workservice/.WPZCommandReceiver -a com.android.workservice.ACTION_DUMP_ICONS >/dev/null 2>&1 || true
fi

# kustomisasi aset (tahan update): taruh file di /data/adb/zless/custom/
# Bawaan: TANPA banner/icon. Baris banner=/webuiIcon= hanya ditulis bila custom ada.
CUSTOM="/data/adb/zless/custom"
if [ -f "$CUSTOM/banner.webp" ]; then
    cp -f "$CUSTOM/banner.webp" "$MODPATH/banner.webp"
    sed -i 's/^banner=.*/banner=banner.webp/' "$MODPATH/module.prop"
elif [ -f "$CUSTOM/banner.png" ]; then
    cp -f "$CUSTOM/banner.png" "$MODPATH/banner.png"
    sed -i 's/^banner=.*/banner=banner.png/' "$MODPATH/module.prop"
else
    sed -i '/^banner=/d' "$MODPATH/module.prop"
fi
if [ -f "$CUSTOM/icon.webp" ]; then
    cp -f "$CUSTOM/icon.webp" "$MODPATH/webroot/icon.webp"
    sed -i 's|^webuiIcon=.*|webuiIcon=webroot/icon.webp|' "$MODPATH/module.prop"
elif [ -f "$CUSTOM/icon.png" ]; then
    cp -f "$CUSTOM/icon.png" "$MODPATH/webroot/icon.png"
    sed -i 's|^webuiIcon=.*|webuiIcon=webroot/icon.png|' "$MODPATH/module.prop"
else
    sed -i '/^webuiIcon=/d' "$MODPATH/module.prop"
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755

set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/bin/zlessd 0 0 0755
set_perm $MODPATH/bin/zlessd_armv7 0 0 0755
set_perm $MODPATH/bin/zlessd_x64 0 0 0755
set_perm $MODPATH/bin/Zclean 0 0 0755
set_perm $MODPATH/zless/mover.sh 0 0 0755
set_perm $MODPATH/zless/spoofer.sh 0 0 0755
[ -f "$MODPATH/bin/resetprop-rs" ] && set_perm $MODPATH/bin/resetprop-rs 0 0 0755

# Detect external modules with duplicate/absorbed features
CONFLICT_FOUND=0
for mod_entry in \
    "zcleaner:ZCleaner (already integrated into CLEANER tab)" \
    "Zcleaner:ZCleaner (already integrated into CLEANER tab)" \
    "ZCleaner:ZCleaner (already integrated into CLEANER tab)" \
    "zclean:ZCleaner (already integrated into CLEANER tab)" \
    "PeridotCN-Spoofer:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "peridotcn-spoofer:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "PeridotCN_Spoofer:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "resetprop_peridot:PeridotCN-Spoofer (already integrated into SPOOFER tab)" \
    "ALING_Serialno:Legacy serial spoofer" \
    "ALING_IMEI:Legacy IMEI spoofer" \
    "Tenc-ano_tmp:Legacy cache cleaner" \
    "tencent_game_assist:Legacy game assist" \
    "zless_unified:Legacy Zless version"; do
    mod_id="${mod_entry%%:*}"
    mod_desc="${mod_entry#*:}"
    if [ -d "/data/adb/modules/$mod_id" ]; then
        if [ "$CONFLICT_FOUND" -eq 0 ]; then
            ui_print " "
            ui_print "***************************************************"
            ui_print "! WARNING: DUPLICATE / CONFLICTING MODULE FOUND !"
            ui_print "***************************************************"
            CONFLICT_FOUND=1
        fi
        ui_print "! Detected: /data/adb/modules/$mod_id"
        ui_print "  -> $mod_desc"
        ui_print "  -> PLEASE REMOVE this module to prevent conflicts!"
    fi
done
if [ "$CONFLICT_FOUND" -eq 1 ]; then
    ui_print "***************************************************"
    ui_print " "
fi

# pulihkan konfigurasi dari versi sebelumnya (tahan update)
PERSIST="/data/adb/zless"
if [ -f "$PERSIST/config.prop" ]; then
    cp -f "$PERSIST/config.prop" "$MODPATH/config.prop"
    ui_print "- Config dipulihkan dari versi sebelumnya."
fi
[ -f "$PERSIST/cpuinfo.txt" ] && cp -f "$PERSIST/cpuinfo.txt" "$MODPATH/cpuinfo.txt"

# backup permission persist (dari modul v4)
if [ -d "/mnt/vendor/persist/data" ] && [ ! -f "$MODPATH/zless/permissions_backup.txt" ]; then
    echo "# Permissions backup - $(date)" > "$MODPATH/zless/permissions_backup.txt"
    chmod 600 "$MODPATH/zless/permissions_backup.txt" 2>/dev/null
    find /mnt/vendor/persist/data -exec stat -c "%a %U:%G %n" {} \; >> "$MODPATH/zless/permissions_backup.txt" 2>/dev/null
    ui_print "- Permission persist di-backup."
fi

# Bersihkan file slot legacy agar script lama tidak tertahan
rm -f /data/adb/.slots /data/adb/.active /data/adb/execute.last.log

# Bersihkan cache icon usang agar diekstrak ulang dengan resolusi presisi
rm -rf /data/adb/modules/zless/icons/* "$MODPATH/icons/*" 2>/dev/null

# Bersihkan file zip Zless lama di folder Download untuk menghilangkan jejak versi lawas
ui_print "- Membersihkan file zip Zless lama dari folder Download..."
for dl in /sdcard/Download /sdcard/Downloads /data/media/*/Download /data/media/*/Downloads /storage/emulated/*/Download /storage/emulated/*/Downloads; do
    if [ -d "$dl" ]; then
        rm -f "$dl"/[Zz]less*.zip "$dl"/[Zz]less*.sha256 "$dl"/[Zz]less*.zip.sha256 2>/dev/null
    fi
done
rm -f /data/local/tmp/[Zz]less*.zip 2>/dev/null

# Restart daemon jika sedang berjalan agar binary baru langsung aktif tanpa reboot
if pidof zlessd >/dev/null 2>&1 || pgrep -f zlessd >/dev/null 2>&1; then
    ui_print "- Me-restart zlessd agar binary baru langsung aktif..."
    pkill -9 -f zlessd 2>/dev/null
    sleep 1
    ABI=$(getprop ro.product.cpu.abi 2>/dev/null)
    [ -n "$ABI" ] || ABI=$(uname -m 2>/dev/null)
    case "$ABI" in
      *arm64*|*aarch64*) D="$MODPATH/bin/zlessd" ;;
      *armv7*|*armeabi*|*armv8l*) D="$MODPATH/bin/zlessd_armv7" ;;
      *x86_64*) D="$MODPATH/bin/zlessd_x64" ;;
      *) D="$MODPATH/bin/zlessd" ;;
    esac
    if [ -x "$D" ]; then
        setsid "$D" --moddir "$MODPATH" >/dev/null 2>&1 &
        ui_print "  [OK] zlessd v${VER} aktif (PID $!)."
    fi
fi

ui_print "- Selesai. Buka WebUI dari aplikasi Magisk/KSU."
