#!/system/bin/sh
# Zless Unified - shared helpers. Source dari script lain: . "$MODDIR/zless/common.sh"

MODDIR=${MODDIR:-$(cd "$(dirname "$0")/.." && pwd)}
ZDIR="$MODDIR/zless"
STATE_DIR="$ZDIR/state"
CONFIG_FILE="$MODDIR/config.prop"
CONFIG_DEFAULT="$MODDIR/config.default"

PERM_BACKUP="$ZDIR/permissions_backup.txt"
TARGET_DIR="/mnt/vendor/persist/data"

mkdir -p "$STATE_DIR" 2>/dev/null

# --- config getters ---
get_switch() {
    grep "^$1=" "$CONFIG_FILE" 2>/dev/null | head -n1 | cut -d= -f2 | tr -d '\r'
}
get_list() {
    sed -n "/^$1=\"/,/^\"$/p" "$CONFIG_FILE" 2>/dev/null | sed '1d;$d' | tr -d '\r'
}
list_to_space() {
    echo "$1" | tr '\n' ' '
}


# --- permission backup/restore /mnt/vendor/persist/data (dari modul v4) ---
backup_permissions() {
    [ -d "$TARGET_DIR" ] || return 1
    [ -f "$PERM_BACKUP" ] && return 0
    echo "# Permissions backup - $(date)" > "$PERM_BACKUP"
    chmod 600 "$PERM_BACKUP" 2>/dev/null
    find "$TARGET_DIR" -exec stat -c "%a %U:%G %n" {} \; >> "$PERM_BACKUP" 2>/dev/null
}
restore_permissions() {
    if [ -f "$PERM_BACKUP" ]; then
        while read -r perm owner path; do
            case "$path" in \#*|"") continue ;; esac
            chmod "$perm" "$path" 2>/dev/null
            chown "$owner" "$path" 2>/dev/null
        done < "$PERM_BACKUP"
        # file baru (dibuat vendor setelah backup) ikut terkunci 000 -> netralkan
        find "$TARGET_DIR" ! -path "$TARGET_DIR" 2>/dev/null | while read -r p; do
            grep -qF " $p$" "$PERM_BACKUP" || {
                if [ -d "$p" ]; then chmod 700 "$p" 2>/dev/null; else chmod 600 "$p" 2>/dev/null; fi
            }
        done
    else
        chmod 700 "$TARGET_DIR" 2>/dev/null
    fi
}

# --- json ---
json_escape() {
    sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\t/\\t/g' -e 's/\r//g' | awk '{if (NR>1) printf "\\n"; printf "%s", $0}'
}
