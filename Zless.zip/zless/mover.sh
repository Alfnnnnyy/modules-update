#!/system/bin/sh
# ==============================================================================
# Zless - Data Mover Engine (Ported from ZCleaner v3.7)
# ==============================================================================

PATH=/system/bin:/system/xbin:/vendor/bin:/product/bin:$PATH
export PATH

LOG_FILE="/data/local/tmp/zcleaner_exec.log"
touch "$LOG_FILE" 2>/dev/null
chmod 666 "$LOG_FILE" 2>/dev/null

log() {
    echo "$@"
    echo "$@" >> "$LOG_FILE"
}

_src="$1"
_dst="$2"
_target="$3"

log "===================================="
log "       PROSES PEMINDAHAN DATA       "
log "===================================="
log "[*] Dari : Profile User $_src"
log "[*] Ke   : Profile User $_dst"
log "------------------------------------"

if [ -z "$_src" ] || [ -z "$_dst" ]; then
    log "[-] Error: Profile asal dan tujuan harus ditentukan."
    exit 1
fi

if [ "$_src" = "$_dst" ]; then
    log "[-] Error: Profile asal dan tujuan tidak boleh sama."
    exit 1
fi

GAMES="com.proximabeta.mf.uamo com.tencent.mf.uam com.garena.game.df com.proxima.dfm com.tencent.tmgp.df com.tencent.rmos"
if [ -n "$_target" ]; then
    GAMES="$_target"
fi

MOVED_COUNT=0

for PKG in $GAMES; do
    SRC_DATA="/data/media/$_src/Android/data/$PKG"
    SRC_OBB="/data/media/$_src/Android/obb/$PKG"
    SRC_INT="/data/user/$_src/$PKG"
    DST_DATA="/data/media/$_dst/Android/data/$PKG"
    DST_OBB="/data/media/$_dst/Android/obb/$PKG"
    DST_INT="/data/user/$_dst/$PKG"

    if [ ! -d "$SRC_DATA" ] && [ ! -d "$SRC_OBB" ] && [ ! -d "$SRC_INT" ]; then
        continue
    fi

    log "[*] Memproses: $PKG"

    # Force stop game di kedua profil agar data tidak terkunci
    am force-stop --user "$_src" "$PKG" 2>/dev/null
    am force-stop --user "$_dst" "$PKG" 2>/dev/null

    DST_UID=""
    if [ -d "$DST_INT" ]; then
        DST_UID=$(stat -c %u "$DST_INT" 2>/dev/null)
        [ "$DST_UID" = "0" ] && DST_UID=""
    fi
    if [ -z "$DST_UID" ]; then
        BASE_UID=$(dumpsys package "$PKG" 2>/dev/null | grep -F "userId=" | head -n1 | awk -F'=' '{print $2}' | tr -d ' \r\n')
        if [ -n "$BASE_UID" ]; then
            DST_UID=$(( _dst * 100000 + BASE_UID ))
        fi
    fi
    if [ -z "$DST_UID" ]; then
        DST_UID=$(ls -dn "/data/user/$_dst/$PKG" 2>/dev/null | awk '{print $3}')
    fi
    if [ -z "$DST_UID" ]; then
        DST_UID=$(pm list packages -U --user "$_dst" "$PKG" 2>/dev/null | grep -F "package:$PKG " | sed -n 's/.*uid:\([0-9][0-9]*\).*/\1/p' | head -n 1)
    fi

    if [ -z "$DST_UID" ]; then
        log "[!] Game $PKG belum terpasang di User $_dst."
        log "[!] Pasang APK game di User $_dst terlebih dahulu agar UID terdaftar."
        continue
    fi

    log "[+] Target UID terdeteksi: $DST_UID"

    # Pindahkan Android/data
    if [ -d "$SRC_DATA" ]; then
        log "[*] Menyalin Android/data ($PKG)..."
        mkdir -p "$DST_DATA"
        cp -af "$SRC_DATA/." "$DST_DATA/" 2>/dev/null

        # Sanitasi data di tujuan: HANYA sisakan asset murni, buang seluruh cache & log sampah
        rm -rf "$DST_DATA/cache" \
               "$DST_DATA/files/cache" \
               "$DST_DATA/files/.cache" \
               "$DST_DATA/files/log" \
               "$DST_DATA/files/logs" \
               "$DST_DATA/files/Record" \
               "$DST_DATA/files/LoadObjStat.log" \
               "$DST_DATA/files/ShadowMallocLog.log" \
               "$DST_DATA/files/Gamelet/program/cookies" \
               "$DST_DATA/files/Gamelet/program/reportcache" \
               "$DST_DATA/files/Gamelet/program/userdatacache" \
               "$DST_DATA/files/g6_player_prefs.ini" \
               "$DST_DATA/files/juscrkat.dat" \
               "$DST_DATA/files/ano_tmp" \
               "$DST_DATA/files/app_crashSight" \
               "$DST_DATA/files/app_crashrecord" \
               "$DST_DATA/files/TGPA" \
               "$DST_DATA/files/AFRequestCache" \
               "$DST_DATA/files/tdm_tmp" \
               "$DST_DATA/files/UE4Game/*/Saved/Logs" \
               "$DST_DATA/files/UE4Game/*/Saved/Crashes" \
               "$DST_DATA/files/UE4Game/*/Saved/SaveGames" \
               "$DST_DATA/files/UE4Game/*/*/Saved/Logs" \
               "$DST_DATA/files/UE4Game/*/*/Saved/Crashes" \
               "$DST_DATA/files/UE4Game/*/*/Saved/SaveGames" \
               "$DST_DATA/files/INTL" \
               "$DST_DATA/files/centauri" \
               "$DST_DATA/files/midas" \
               "$DST_DATA/files/tencent" 2>/dev/null

        log "[*] Menyesuaikan hak akses ($DST_UID) & SELinux..."
        chown -R "$DST_UID:$DST_UID" "$DST_DATA" 2>/dev/null
        find "$DST_DATA" -type d -exec chmod 775 {} + 2>/dev/null
        find "$DST_DATA" -type f -exec chmod 664 {} + 2>/dev/null
        restorecon -R "$DST_DATA" 2>/dev/null
        log "[+] Data game berhasil dipindahkan ke User $_dst."
    fi

    # Khusus Delta Force: 7.7GB resource tersimpan di internal /data/user/$_src/$PKG/files/UE4Game
    SRC_DF_INT="/data/user/$_src/$PKG/files/UE4Game"
    DST_DF_INT="/data/user/$_dst/$PKG/files/UE4Game"
    if [ -d "$SRC_DF_INT" ]; then
        log "[*] Memindahkan resource internal Delta Force ($SRC_DF_INT -> $DST_DF_INT)..."
        mkdir -p "/data/user/$_dst/$PKG/files"
        cp -af "$SRC_DF_INT" "/data/user/$_dst/$PKG/files/" 2>/dev/null
        rm -rf "$DST_DF_INT/DeltaForce/DeltaForce/SavedLoadTrack" \
               "$DST_DF_INT/DeltaForce/DeltaForce/Saved/Config/CrashReportClient" 2>/dev/null
    fi

    # Sanitasi internal destination profile agar akun lama & sampah di profil tujuan hangus total
    if [ -d "$DST_INT" ]; then
        rm -rf "$DST_INT/shared_prefs" \
               "$DST_INT/databases" \
               "$DST_INT/cache" \
               "$DST_INT/code_cache" \
               "$DST_INT/no_backup" \
               "$DST_INT/app_crashSight" \
               "$DST_INT/app_crashrecord" \
               "$DST_INT/files/.system_android_l2" \
               "$DST_INT/files/ace_shell_di.dat" \
               "$DST_INT/files/tdm_track.dat" \
               "$DST_INT/files/login-identifier.txt" \
               "$DST_INT/files/HANYCJLZOEUS_TOKEN2.dat" \
               "$DST_INT/files/INTL" \
               "$DST_INT/files/AFRequestCache" \
               "$DST_INT/files/tdm_tmp" 2>/dev/null
        chown -R "$DST_UID:$DST_UID" "$DST_DF_INT" 2>/dev/null
        restorecon -R "$DST_DF_INT" 2>/dev/null
        log "[+] Resource internal Delta Force berhasil dipindahkan ke User $_dst."
    fi

    # Pindahkan Android/obb
    if [ -d "$SRC_OBB" ]; then
        log "[*] Menyalin Android/obb ($PKG)..."
        mkdir -p "$DST_OBB"
        cp -af "$SRC_OBB/." "$DST_OBB/" 2>/dev/null
        chown -R "$DST_UID:$DST_UID" "$DST_OBB" 2>/dev/null

        find "$DST_OBB" -type d -exec chmod 775 {} + 2>/dev/null
        find "$DST_OBB" -type f -exec chmod 664 {} + 2>/dev/null
        restorecon -R "$DST_OBB" 2>/dev/null
        log "[+] OBB berhasil dipindahkan ke User $_dst."
    fi

    # 3. Pindahkan Internal Data (/data/user/X/$PKG) — Kritis untuk Delta Force & UE4
    if [ -d "$SRC_INT" ]; then
        log "[*] Menyalin Internal Game Assets ($SRC_INT)..."
        mkdir -p "$DST_INT"

        # Salin direktori data murni (files/, app_textures/, no_backup/)
        for sub in files app_textures no_backup; do
            if [ -d "$SRC_INT/$sub" ]; then
                log "[*] Menyalin internal $sub/..."
                mkdir -p "$DST_INT/$sub"
                cp -af "$SRC_INT/$sub/." "$DST_INT/$sub/" 2>/dev/null
            fi
        done
        chown -R "$DST_UID:$DST_UID" "$DST_INT" 2>/dev/null
        restorecon -R "$DST_INT" 2>/dev/null
        log "[+] Internal assets berhasil disalin ke User $_dst."
    fi

    MOVED_COUNT=$((MOVED_COUNT + 1))
    log "------------------------------------"
done

sync
log "===================================="
if [ "$MOVED_COUNT" -gt 0 ]; then
    log "[✓] Selesai! $MOVED_COUNT game berhasil dipindahkan ke User $_dst."
    log "[+] Game langsung siap dimainkan di profil tujuan tanpa unduh ulang."
else
    log "[-] Tidak ditemukan file data game pada User $_src."
fi
