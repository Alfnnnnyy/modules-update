#!/system/bin/sh
# drmid.sh — Widevine DrmID spoof engine for Zless
# Ported from timepd drmid_spoof

MODDIR=${MODDIR:-$(cd "$(dirname "$0")/.." && pwd)}
D="${DRMID_STATE_DIR:-/data/adb/drmid_spoof}"
HEX="$D/drmid.hex"
MODEF="$D/mode"
APPSF="$D/apps"
UIDSF="$D/uids"
PIDF="$D/daemon.pid"
AUTOF="$D/auto_reroll"

mkdir -p "$D" 2>/dev/null

_susfs_hide() {
    for _s in /data/adb/ksu/bin/ksu_susfs /data/adb/ksu/bin/susfs /data/adb/ap/bin/ksu_susfs /data/adb/ap/bin/susfs /data/adb/modules/susfs4ksu/susfs; do
        if [ -x "$_s" ]; then
            "$_s" add_sus_path_loop "$D" 2>/dev/null
            break
        fi
    done
}

_hup() {
    [ -f "$PIDF" ] && kill -HUP "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null
}

_daemon() {
    if [ -f "$PIDF" ]; then
        _pid=$(cat "$PIDF" 2>/dev/null)
        if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
            echo "running"
            return 0
        fi
    fi
    # Check by process name as fallback
    if pidof drmid_daemon >/dev/null 2>&1; then
        pidof drmid_daemon | awk '{print $1}' > "$PIDF" 2>/dev/null
        echo "running"
        return 0
    fi
    echo "stopped"
    return 1
}

_val() {
    [ -s "$HEX" ] && tr -d ' \r\n' < "$HEX"
}

_auto() {
    [ -s "$AUTOF" ] && tr -d ' \r\n' < "$AUTOF" || echo "关闭"
}

_mode() {
    [ -s "$MODEF" ] && tr -d ' \r\n' < "$MODEF" || echo "off"
}

_is_hex64() {
    case "$1" in
        *[!0-9a-fA-F]*) return 1 ;;
    esac
    [ "${#1}" -eq 64 ]
}

_apps_json() {
    printf '['
    if [ -s "$APPSF" ]; then
        first=1
        while IFS= read -r p; do
            [ -z "$p" ] && continue
            [ $first -eq 1 ] && first=0 || printf ','
            printf '"%s"' "$p"
        done < "$APPSF"
    fi
    printf ']'
}

_uids_of() {
    _target_pkg="$1"
    _found_any=""
    # 1. User 0 stat
    _u=$(stat -c %u "/data/data/$_target_pkg" 2>/dev/null)
    [ -n "$_u" ] && echo "$_u" && _found_any=1

    # 2. Check all active users (User 0, Work Profile User 10, etc.)
    for _user in $(pm list users 2>/dev/null | grep -oE '\{[0-9]+:' | tr -d '{:'); do
        if [ "$_user" -ne 0 ]; then
            _u=$(stat -c %u "/data/user/$_user/$_target_pkg" 2>/dev/null)
            if [ -n "$_u" ]; then
                echo "$_u"
                _found_any=1
                continue
            fi
        fi
        _u=$(pm list packages -U --user "$_user" "$_target_pkg" 2>/dev/null | grep -o 'uid:[0-9]*' | cut -d: -f2 | head -n1)
        [ -n "$_u" ] && echo "$_u" && _found_any=1
    done

    # 3. Fallback to dumpsys if empty
    if [ -z "$_found_any" ]; then
        _u=$(dumpsys package "$_target_pkg" 2>/dev/null | grep -m1 'userId=' | sed 's/.*userId=\([0-9]*\).*/\1/')
        [ -n "$_u" ] && echo "$_u"
    fi
}

_start_daemon() {
    if [ "$(_daemon)" != "running" ]; then
        _susfs_hide
        mkdir -p "$D" 2>/dev/null
        if [ -f "$MODDIR/bin/libdrmid_hook.so" ]; then
            cp -f "$MODDIR/bin/libdrmid_hook.so" "$D/libdrmid_hook.so" 2>/dev/null
            chmod 0644 "$D/libdrmid_hook.so" 2>/dev/null
        fi
        if [ -x "$MODDIR/bin/drmid_daemon" ]; then
            nohup "$MODDIR/bin/drmid_daemon" --hook "$D/libdrmid_hook.so" >>"$D/daemon.log" 2>&1 &
            echo "$!" > "$PIDF"
        fi
    fi
}

case "$1" in
    status)
        m=$(_mode)
        # Auto-heal: restart daemon if active mode but daemon stopped
        if [ "$m" != "off" ] && [ "$(_daemon)" != "running" ]; then
            _start_daemon
        fi
        v=$(_val)
        act=false
        if [ "$m" != "off" ] && [ -n "$v" ]; then
            if [ "$m" = "global" ]; then
                act=true
            elif [ "$m" = "app" ] && [ -s "$UIDSF" ]; then
                act=true
            fi
        fi
        _target=$(cat "$D/injected_target" 2>/dev/null)
        _ar=false
        [ "$(_auto)" = "开启" ] && _ar=true
        printf '{"ok":true,"daemon":"%s","target":"%s","mode":"%s","value":"%s","apps":%s,"active":%s,"auto_reroll":%s}\n' \
            "$(_daemon)" "$_target" "$m" "$v" "$(_apps_json)" "$act" "$_ar"
        ;;
    mode)
        case "$2" in
            off)
                printf 'off' > "$MODEF"
                if [ -f "$PIDF" ]; then
                    kill "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null
                    rm -f "$PIDF"
                fi
                pkill -f drmid_daemon 2>/dev/null
                rm -f "$D/injected_target" 2>/dev/null
                echo '{"ok":true,"mode":"off"}'
                ;;
            global|app)
                printf '%s' "$2" > "$MODEF"
                # If setting active mode and no value exists yet, generate random value
                if [ ! -s "$HEX" ]; then
                    H=$(head -c 32 /dev/urandom 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
                    [ ${#H} -eq 64 ] && printf '%s' "$H" > "$HEX" && chmod 0600 "$HEX" 2>/dev/null
                fi
                _start_daemon
                _hup
                echo "{\"ok\":true,\"mode\":\"$2\"}"
                ;;
            *)
                echo '{"ok":false,"error":"bad_mode"}'
                exit 2
                ;;
        esac
        ;;
    setval)
        if ! _is_hex64 "$2"; then
            echo '{"ok":false,"error":"need 64 hex chars"}'
            exit 2
        fi
        printf '%s' "$2" | tr 'A-F' 'a-f' > "$HEX"
        chmod 0600 "$HEX" 2>/dev/null
        _hup
        echo "{\"ok\":true,\"value\":\"$(_val)\"}"
        ;;
    random)
        H=$(head -c 32 /dev/urandom 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
        if [ ${#H} -ne 64 ]; then
            H=$(head -c 32 /dev/urandom 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
        fi
        if [ ${#H} -ne 64 ]; then
            # Fallback random generation
            H=$(date +%s%N 2>/dev/null | md5sum | cut -c1-32)$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '-' | cut -c1-32)
        fi
        printf '%s' "$H" | tr 'A-F' 'a-f' > "$HEX"
        chmod 0600 "$HEX" 2>/dev/null
        _hup
        echo "{\"ok\":true,\"value\":\"$H\"}"
        ;;
    apps)
        shift
        : > "$APPSF"
        : > "$UIDSF"
        for p in $(printf '%s' "$*" | tr ',' ' '); do
            [ -z "$p" ] && continue
            echo "$p" >> "$APPSF"
            for u in $(_uids_of "$p"); do
                [ -n "$u" ] && echo "$u" >> "$UIDSF"
            done
        done
        [ -s "$UIDSF" ] && sort -u "$UIDSF" -o "$UIDSF" 2>/dev/null
        chmod 0600 "$APPSF" "$UIDSF" 2>/dev/null
        _hup
        echo "{\"ok\":true,\"apps\":$(_apps_json)}"
        ;;
    toggle_auto)
        if [ "$(_auto)" = "开启" ]; then
            printf '关闭' > "$AUTOF"
            echo '{"ok":true,"auto_reroll":false}'
        else
            printf '开启' > "$AUTOF"
            echo '{"ok":true,"auto_reroll":true}'
        fi
        ;;
    boot)
        _susfs_hide
        if [ "$(_mode)" != "off" ]; then
            if [ "$(_auto)" = "开启" ]; then
                H=$(head -c 32 /dev/urandom 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
                [ ${#H} -eq 64 ] && printf '%s' "$H" | tr 'A-F' 'a-f' > "$HEX" && chmod 0600 "$HEX" 2>/dev/null
                _hup
            fi
            _start_daemon
        fi
        echo '{"ok":true}'
        ;;
    restart_hal)
        pkill -f 'android\.hardware\.drm.*widevine' 2>/dev/null
        sleep 0.5
        _hup
        echo '{"ok":true}'
        ;;
    start)
        _start_daemon
        echo "{\"ok\":true}"
        ;;
    stop)
        if [ -f "$PIDF" ]; then
            kill "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null
            rm -f "$PIDF"
        fi
        pkill -f drmid_daemon 2>/dev/null
        echo "{\"ok\":true}"
        ;;
    hup)
        _hup
        echo "{\"ok\":true}"
        ;;
    *)
        echo '{"ok":false,"error":"unknown_cmd"}'
        exit 1
        ;;
esac
