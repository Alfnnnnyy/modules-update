#!/system/bin/sh
# Zless Universal Spoofer Engine
# Integrated from PeridotCN-Spoofer — Universal device spoofer with TEE parity, Tier-B seal, & ADB stealth.

MODDIR=${MODDIR:-$(cd "$(dirname "$0")/.." && pwd)}
BIN="$MODDIR/bin/resetprop-rs"
ZDIR="$MODDIR/zless"
CONFIG_FILE="$MODDIR/config.prop"
[ -f "$CONFIG_FILE" ] || CONFIG_FILE="$MODDIR/config.default"
SERIAL_FILE="$ZDIR/state/spoofer_serial"
IMEI_FILE="$ZDIR/state/spoofer_imei"
mkdir -p "$ZDIR/state" 2>/dev/null

[ -x "$BIN" ] || chmod 755 "$BIN" 2>/dev/null

get_cfg() {
    grep "^$1=" "$CONFIG_FILE" 2>/dev/null | head -n1 | cut -d= -f2 | tr -d '\r '
}

random_digits() {
    _n="$1"
    _digits=$(head -c 64 /dev/urandom 2>/dev/null | tr -cd '0-9')
    if [ -z "$_digits" ]; then
        _seed=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '-')$(date +%s%N 2>/dev/null)$(cat /proc/uptime 2>/dev/null)
        _digits=$(printf '%s' "$_seed" | tr -cd '0-9')
    fi
    while [ ${#_digits} -lt "$_n" ]; do
        _more=$(head -c 32 /dev/urandom 2>/dev/null | tr -cd '0-9')
        _digits="${_digits}${_more:-0123456789}"
    done
    printf '%s' "${_digits:0:$_n}"
}

gen_identities() {
    # 1. Serial (16 hex)
    _seed="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '-')$(cat /proc/uptime 2>/dev/null | cut -d. -f1)"
    SERIAL=$(printf '%s' "${_seed}" | od -An -t x1 2>/dev/null | tr -d ' \n' | head -c 16)
    [ ${#SERIAL} -lt 16 ] && SERIAL=$(printf '%s' "$_seed" | md5sum 2>/dev/null | cut -c1-16)
    [ ${#SERIAL} -lt 16 ] && SERIAL="3766313338396132"
    printf '%s' "$SERIAL" > "$SERIAL_FILE"

    # 2. OEM Serial (16 uppercase alnum)
    _charset="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    OEM_SERIAL=""
    _i=0
    while [ $_i -lt 32 ] && [ ${#OEM_SERIAL} -lt 16 ]; do
        _byte="${SERIAL:$_i:2}"
        _dec=$((0x${_byte:-00}))
        _idx=$((_dec % 36))
        OEM_SERIAL="${OEM_SERIAL}${_charset:$_idx:1}"
        _i=$((_i + 2))
    done
    while [ ${#OEM_SERIAL} -lt 16 ]; do OEM_SERIAL="${OEM_SERIAL}A"; done

    # 3. SNO & PSNO
    SNO="$(random_digits 5)O$(random_digits 6)"
    PSNO="$(random_digits 5)/$(random_digits 2)W$(random_digits 6)"

    # 4. Dual IMEI (15 digits)
    IMEI1="86916$(random_digits 10)"
    IMEI2="86916$(random_digits 10)"
    printf '%s\n%s' "$IMEI1" "$IMEI2" > "$IMEI_FILE"
}

load_identities() {
    _mode="$1"
    AUTO_REROLL=$(get_cfg AUTO_REROLL)
    [ -z "$AUTO_REROLL" ] && AUTO_REROLL="开启"

    if [ "$_mode" = "boot" ] && [ "$AUTO_REROLL" = "开启" ]; then
        gen_identities
    elif [ ! -f "$SERIAL_FILE" ] || [ ! -f "$IMEI_FILE" ]; then
        gen_identities
    else
        SERIAL=$(head -n1 "$SERIAL_FILE" 2>/dev/null)
        IMEI1=$(head -n1 "$IMEI_FILE" 2>/dev/null)
        IMEI2=$(tail -n1 "$IMEI_FILE" 2>/dev/null)
        [ -z "$SERIAL" ] && gen_identities
    fi
}

apply_preset() {
    PRESET=$(get_cfg SPOOFER_PRESET)
    [ -z "$PRESET" ] && PRESET="Turbo3"
    [ "$PRESET" = "OFF" ] && return 0
    [ -x "$BIN" ] || return 0

    load_identities "$1"

    # Auto security patch sync with TEE
    _cur_year=$(date +%Y 2>/dev/null || echo 0)
    if [ "$_cur_year" -ge 2026 ]; then
        PATCH_DATE="$(date +%Y-%m-01 2>/dev/null)"
    else
        _data_year=$(date -r /data/system +%Y 2>/dev/null || echo 0)
        if [ "$_data_year" -ge 2026 ]; then
            PATCH_DATE="$(date -r /data/system +%Y-%m-01 2>/dev/null)"
        else
            PATCH_DATE="2026-09-01"
        fi
    fi
    [ -z "$PATCH_DATE" ] && PATCH_DATE="2026-09-01"

    FIRSTBOOT="$(date +%s 2>/dev/null)000"
    [ -z "$FIRSTBOOT" ] || [ "$FIRSTBOOT" = "000" ] && FIRSTBOOT="1724803200000"
    HOSTNAME="android-$SERIAL"

    DEV_FILE="$MODDIR/zless/devices.conf"
    LINE=$(grep "^${PRESET}|" "$DEV_FILE" 2>/dev/null | head -1)
    if [ -z "$LINE" ]; then
        LINE=$(grep "^Turbo3|" "$DEV_FILE" 2>/dev/null | head -1)
    fi
    IFS='|' read -r _id MODEL MARKETNAME BRAND MANUFACTURER BUILD_ID INCREMENTAL FP SOC_MODEL <<EOF
$LINE
EOF

    # 1. Identity Props (Board/device untouched for 100% safety)
    for p in ro.product.model ro.product.system.model ro.product.vendor.model ro.product.odm.model ro.product.product.model ro.product.system_ext.model ro.product.system_dlkm.model ro.product.vendor_dlkm.model ro.product.bootimage.model ro.product.model_for_attestation ro.product.cert; do
        "$BIN" --stealth "$p" "$MODEL" 2>/dev/null
    done
    for p in ro.product.brand ro.product.system.brand ro.product.vendor.brand ro.product.odm.brand ro.product.product.brand ro.product.system_ext.brand ro.product.system_dlkm.brand ro.product.vendor_dlkm.brand ro.product.bootimage.brand ro.product.brand_for_attestation; do
        "$BIN" --stealth "$p" "$BRAND" 2>/dev/null
    done
    for p in ro.product.manufacturer ro.product.system.manufacturer ro.product.vendor.manufacturer ro.product.odm.manufacturer ro.product.product.manufacturer ro.product.system_ext.manufacturer ro.product.system_dlkm.manufacturer ro.product.vendor_dlkm.manufacturer ro.product.bootimage.manufacturer ro.product.manufacturer_for_attestation; do
        "$BIN" --stealth "$p" "$MANUFACTURER" 2>/dev/null
    done
    if [ -n "$MARKETNAME" ]; then
        for p in ro.product.marketname ro.product.system.marketname ro.product.vendor.marketname ro.product.odm.marketname ro.product.product.marketname ro.product.system_ext.marketname ro.product.system_dlkm.marketname ro.product.vendor_dlkm.marketname ro.product.bootimage.marketname bluetooth.device.default_name; do
            "$BIN" --stealth "$p" "$MARKETNAME" 2>/dev/null
        done
    fi
    # Safety: restore stock Qualcomm modem properties if previously mutated (fixes RIL crash)
    _qti_soc=$(getprop ro.vendor.qti.soc_model 2>/dev/null)
    case "$_qti_soc" in
        SM8750|SM8650)
            "$BIN" --stealth ro.vendor.qti.soc_model "SM8635" 2>/dev/null
            "$BIN" --stealth ro.vendor.qti.soc_name "cliffs" 2>/dev/null
            "$BIN" --stealth ro.vendor.qti.soc_id "614" 2>/dev/null
            ;;
    esac

    # Clean up any legacy soc0 mounts so /proc/self/mountinfo never leaks /data/adb paths to VDInfos
    umount -l /sys/devices/soc0/soc_id 2>/dev/null
    umount -l /sys/devices/soc0/machine 2>/dev/null
    umount -l "$ZDIR/state/soc_id" 2>/dev/null
    umount -l "$ZDIR/state/soc_machine" 2>/dev/null
    rm -f "$ZDIR/state/soc_id" "$ZDIR/state/soc_machine" 2>/dev/null

    # Apply kernel open_redirect and ro.soc.* props if preset defines SOC_MODEL
    [ -n "$SOC_MODEL" ] && apply_soc_redirect "$SOC_MODEL"

    # 2. Build Version & Patch (Universal dynamic: keep native release & SDK to prevent Zygote crash)
    NATIVE_RELEASE=$(getprop ro.build.version.release 2>/dev/null)
    "$BIN" --stealth ro.build.id "$BUILD_ID" 2>/dev/null
    "$BIN" --stealth ro.build.version.incremental "$INCREMENTAL" 2>/dev/null
    for p in ro.build.version.security_patch ro.vendor.build.security_patch ro.keymaster.xxx.security_patch ro.bootimage.build.security_patch; do
        "$BIN" --stealth "$p" "$PATCH_DATE" 2>/dev/null
    done

    # 3. Fingerprint (10 Partitions)
    DISABLE_FP=$(get_cfg DISABLE_FP_SPOOF)
    if [ "$DISABLE_FP" != "开启" ]; then
        if [ -n "$NATIVE_RELEASE" ] && [ -n "$FP" ]; then
            FP=$(printf '%s' "$FP" | sed -E "s/:[0-9]+(\.[0-9]+)?\//:${NATIVE_RELEASE}\//")
        fi
        for p in ro.build.fingerprint ro.system.build.fingerprint ro.product.build.fingerprint ro.vendor.build.fingerprint ro.odm.build.fingerprint ro.bootimage.build.fingerprint ro.system_ext.build.fingerprint ro.system_dlkm.build.fingerprint ro.vendor_dlkm.build.fingerprint ro.odm_dlkm.build.fingerprint; do
            "$BIN" --stealth "$p" "$FP" 2>/dev/null
        done
    fi

    # 4. Physical Identifiers
    "$BIN" --stealth ro.serialno "$SERIAL" 2>/dev/null
    "$BIN" --stealth ro.boot.serialno "$SERIAL" 2>/dev/null
    [ -n "$OEM_SERIAL" ] && "$BIN" --stealth ro.vendor.oem.serialno "$OEM_SERIAL" 2>/dev/null
    [ -n "$SNO" ] && { "$BIN" --stealth ro.vendor.oem.sno "$SNO" 2>/dev/null; "$BIN" --stealth ro.ril.oem.sno "$SNO" 2>/dev/null; }
    [ -n "$PSNO" ] && { "$BIN" --stealth ro.vendor.oem.psno "$PSNO" 2>/dev/null; "$BIN" --stealth ro.ril.oem.psno "$PSNO" 2>/dev/null; }

    # Dual IMEI
    for p in ro.ril.oem.imei ro.ril.oem.imei1 ro.telephony.imei ro.telephony.imei1 persist.radio.imei persist.radio.imei1 persist.vendor.radio.imei persist.vendor.radio.imei1 ro.ril.miui.imei0; do
        "$BIN" --stealth "$p" "$IMEI1" 2>/dev/null
    done
    for p in ro.ril.oem.imei2 ro.telephony.imei2 persist.radio.imei2 persist.vendor.radio.imei2 ro.ril.miui.imei1; do
        "$BIN" --stealth "$p" "$IMEI2" 2>/dev/null
    done

    # 5. Security Hardening
    "$BIN" --stealth ro.debuggable "0" 2>/dev/null
    "$BIN" --stealth ro.secure "1" 2>/dev/null
    "$BIN" --stealth ro.adb.secure "1" 2>/dev/null
    "$BIN" --stealth ro.build.type "user" 2>/dev/null
    "$BIN" --stealth ro.build.tags "release-keys" 2>/dev/null
    "$BIN" --stealth ro.boot.verifiedbootstate "green" 2>/dev/null
    "$BIN" --stealth ro.boot.flash.locked "1" 2>/dev/null
    "$BIN" --stealth ro.boot.vbmeta.device_state "locked" 2>/dev/null
    "$BIN" --stealth ro.boot.veritymode "enforcing" 2>/dev/null
    "$BIN" --stealth ro.secureboot.lockstate "locked" 2>/dev/null
    "$BIN" --stealth sys.oem_unlock_allowed "0" 2>/dev/null
    "$BIN" --stealth ro.boot.warranty_bit "0" 2>/dev/null
    "$BIN" --stealth ro.warranty_bit "0" 2>/dev/null
    "$BIN" --stealth ro.build.selinux "1" 2>/dev/null

    # 6. Network & Firstboot
    "$BIN" --stealth ro.runtime.firstboot "$FIRSTBOOT" 2>/dev/null
    "$BIN" --stealth net.hostname "$HOSTNAME" 2>/dev/null
    echo "$HOSTNAME" > /proc/sys/kernel/hostname 2>/dev/null || true
}

apply_nukes() {
    [ -x "$BIN" ] || return 0
    NUKE_CONF="$MODDIR/zless/nuke.conf"
    if [ -f "$NUKE_CONF" ]; then
        while IFS='=' read -r prop rest; do
            case "$prop" in \#*|"") continue ;; esac
            prop=$(printf '%s' "$prop" | tr -d '[:space:]')
            "$BIN" --nuke "$prop" 2>/dev/null
        done < "$NUKE_CONF"
    fi
}

apply_adb_stealth() {
    [ -x "$BIN" ] || return 0
    ADB_VAL=$(get_cfg ADB_STEALTH)
    if [ "$ADB_VAL" = "开启" ]; then
        "$BIN" --stealth persist.sys.usb.config "none" 2>/dev/null
        "$BIN" --stealth persist.security.adbinput "0" 2>/dev/null
        "$BIN" --stealth sys.usb.adb.disabled "1" 2>/dev/null
        "$BIN" --stealth ro.boottime.adbd "0" 2>/dev/null
        rm -f /data/misc/adb/adb_keys /data/misc/adb/adb_temp_keys* 2>/dev/null
        rm -rf /data/local/tmp/* /data/local/tmp/.[!.]* 2>/dev/null
        chown 2000:2000 /data/local/tmp 2>/dev/null
        chmod 0771 /data/local/tmp 2>/dev/null
    else
        setprop sys.usb.adb.disabled 0 2>/dev/null
        setprop persist.security.adbinput 1 2>/dev/null
    fi
}

apply_seal() {
    PRESET=$(get_cfg SPOOFER_PRESET)
    [ "$PRESET" = "OFF" ] && return 0
    [ -x "$BIN" ] || return 0

    # Tier-B kernel seal on critical props
    for p in ro.debuggable ro.secure ro.adb.secure ro.boot.verifiedbootstate ro.boot.flash.locked ro.boot.vbmeta.device_state ro.boot.veritymode ro.secureboot.lockstate sys.oem_unlock_allowed ro.boot.warranty_bit ro.warranty_bit ro.build.selinux; do
        val=$(getprop "$p")
        [ -n "$val" ] && "$BIN" --seal "$p" "$val" 2>/dev/null
    done
}

apply_soc_redirect() {
    _raw_soc="$1"
    [ -z "$_raw_soc" ] && return 0
    [ -x "$BIN" ] || return 0

    _sid=""
    _smach=""
    _mfg="Qualcomm"
    _model=""

    case "$_raw_soc" in
        *8850*|*8835*|*"8 Gen 5"*) _sid=680; _smach="SUN"; _model="SM8850" ;;
        *SM8750*|*8750*|*"8 Elite"*|*"8 Gen 4"*) _sid=618; _smach="SUN"; _model="SM8750" ;;
        *SM8650*|*8650*|*"8 Gen 3"*) _sid=519; _smach="PINEAPPLE"; _model="SM8650" ;;
        *SM8635*|*8635*|*"8s Gen 3"*) _sid=614; _smach="CLIFFS"; _model="SM8635" ;;
        *SM7675*|*7675*|*"7+ Gen 3"*) _sid=616; _smach="CLIFFS"; _model="SM7675" ;;
        *SM8550*|*8550*|*"8 Gen 2"*) _sid=519; _smach="KALAMA"; _model="SM8550" ;;
        *SM7475*|*7475*|*"7+ Gen 2"*) _sid=530; _smach="KALAMA"; _model="SM7475" ;;
        *SM8475*|*8475*|*"8+ Gen 1"*) _sid=530; _smach="CAPE"; _model="SM8475" ;;
        *SM8450*|*8450*|*"8 Gen 1"*) _sid=457; _smach="TARO"; _model="SM8450" ;;
        *SM7550*|*"7s Gen 3"*|*"7 Gen 3"*) _sid=578; _smach="CROW"; _model="SM7550" ;;
        *SM8350*|*888*) _sid=415; _smach="LAHAINA"; _model="SM8350" ;;
        *SM8250*|*870*|*865*) _sid=356; _smach="KONA"; _model="SM8250" ;;
        *SM7325*|*778G*) _sid=467; _smach="YUKON"; _model="SM7325" ;;
        *SM8150*|*855*) _sid=339; _smach="MSMNILE"; _model="SM8150" ;;
        *MT*|*Dimensity*) _sid="0"; _smach="UNKNOWN"; _mfg="Mediatek"; _model="MT6991" ;;
        *Exynos*|*S5E*) _sid="0"; _smach="UNKNOWN"; _mfg="Samsung"; _model="S5E9945" ;;
        *Tensor*) _sid="0"; _smach="UNKNOWN"; _mfg="Google"; _model="Tensor-G4" ;;
        *Kirin*|*hi36*) _sid="0"; _smach="UNKNOWN"; _mfg="Huawei"; _model="Kirin9010" ;;
        *Apple*|*A18*|*A17*|*M4*) _sid="0"; _smach="UNKNOWN"; _mfg="Apple"; _model="Apple-M4" ;;
        *) _model="$_raw_soc" ;;
    esac

    [ -n "$_model" ] && "$BIN" --stealth ro.soc.model "$_model" 2>/dev/null
    "$BIN" --stealth ro.soc.manufacturer "$_mfg" 2>/dev/null

    # Kernel VFS open_redirect (Zero mountpoint, 0 /proc/self/mountinfo leak)
    if [ -n "$_sid" ] && [ -x /data/adb/ksu/bin/ksu_susfs ]; then
        mkdir -p /dev/.zless 2>/dev/null
        echo -n "$_sid" > /dev/.zless/soc_id
        echo -n "$_smach" > /dev/.zless/soc_mach
        chmod 644 /dev/.zless/soc_id /dev/.zless/soc_mach
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/soc_id /dev/.zless/soc_id 3 2>/dev/null
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/machine /dev/.zless/soc_mach 3 2>/dev/null
    fi
}

restore_soc_redirect() {
    "$BIN" --stealth ro.soc.model "SM8635" 2>/dev/null
    "$BIN" --stealth ro.soc.manufacturer "QTI" 2>/dev/null
    if [ -x /data/adb/ksu/bin/ksu_susfs ] && [ -d /dev/.zless ]; then
        echo -n "614" > /dev/.zless/soc_id
        echo -n "CLIFFS" > /dev/.zless/soc_mach
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/soc_id /dev/.zless/soc_id 3 2>/dev/null
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/machine /dev/.zless/soc_mach 3 2>/dev/null
    fi
}

case "$1" in
    post-fs-data)
        apply_nukes
        apply_preset boot
        apply_adb_stealth
        ;;
    service)
        apply_seal
        ;;
    apply)
        apply_preset
        apply_adb_stealth
        ;;
    reroll)
        gen_identities
        apply_preset
        ;;
    toggle-adb)
        apply_adb_stealth
        ;;
    soc)
        apply_soc_redirect "$2"
        ;;
    restore-soc)
        restore_soc_redirect
        ;;
    *)
        echo "Usage: $0 {post-fs-data|service|apply|reroll|toggle-adb}"
        exit 1
        ;;
esac
