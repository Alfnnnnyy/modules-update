#!/system/bin/sh
# Zless Universal Spoofer Engine
# Integrated from PeridotCN-Spoofer — Universal device spoofer with TEE parity, Tier-B seal, & ADB stealth.

MODDIR=${MODDIR:-$(cd "$(dirname "$0")/.." && pwd)}
BIN="$MODDIR/bin/resetprop-rs"
ZDIR="$MODDIR/zless"
CONFIG_FILE="$MODDIR/config.prop"
[ -f "$CONFIG_FILE" ] || CONFIG_FILE="$MODDIR/config.default"
SERIAL_FILE="$ZDIR/state/spoofer_serial"
IMEI_FILE="$ZDIR/state/spoofer_imei"
mkdir -p "$ZDIR/state" 2>/dev/null

[ -x "$BIN" ] || chmod 755 "$BIN" 2>/dev/null

get_cfg() {
    grep "^$1=" "$CONFIG_FILE" 2>/dev/null | head -n1 | cut -d= -f2 | tr -d '\r '
}

random_digits() {
    _n="$1"
    _digits=$(head -c 64 /dev/urandom 2>/dev/null | tr -cd '0-9')
    if [ -z "$_digits" ]; then
        _seed=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '-')$(date +%s%N 2>/dev/null)$(cat /proc/uptime 2>/dev/null)
        _digits=$(printf '%s' "$_seed" | tr -cd '0-9')
    fi
    while [ ${#_digits} -lt "$_n" ]; do
        _more=$(head -c 32 /dev/urandom 2>/dev/null | tr -cd '0-9')
        _digits="${_digits}${_more:-0123456789}"
    done
    printf '%s' "${_digits:0:$_n}"
}

gen_wifi_mac() {
    _hex=$(head -c 16 /dev/urandom 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
    [ -z "$_hex" ] && _hex=$(date +%s%N 2>/dev/null | md5sum | head -c 12)
    [ -z "$_hex" ] && _hex="123456789ABC"
    _b0=$(printf '%02x' $(( 0x${_hex:0:2} & 0xfe | 0x02 )))
    _mac="${_b0}:${_hex:2:2}:${_hex:4:2}:${_hex:6:2}:${_hex:8:2}:${_hex:10:2}"
    printf '%s' "$_mac" | tr 'a-z' 'A-Z'
}

normalize_patch_date() {
    _raw="$1"
    [ -z "$_raw" ] && return 1
    _raw=$(printf '%s' "$_raw" | tr -d ' "\r\n')
    case "$_raw" in
        [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9])
            echo "$_raw"
            return 0
            ;;
        [0-9][0-9][0-9][0-9]-[0-9][0-9])
            echo "${_raw}-01"
            return 0
            ;;
        [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])
            echo "${_raw:0:4}-${_raw:4:2}-${_raw:6:2}"
            return 0
            ;;
        [0-9][0-9][0-9][0-9][0-9][0-9])
            echo "${_raw:0:4}-${_raw:4:2}-01"
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

detect_attestation_patch() {
    # 1. Live KeyStore Hardware Attestation probe result
    if [ -s /data/adb/zless/attestation_patch.txt ]; then
        _val=$(head -n1 /data/adb/zless/attestation_patch.txt 2>/dev/null | tr -d '\r ')
        _norm=$(normalize_patch_date "$_val")
        if [ -n "$_norm" ]; then
            echo "$_norm"
            return 0
        fi
    fi
    apply_susfs_hw_redirect "$1"
    apply_carrier_spoof
    apply_telemetry_sinkhole
    isolate_ace_threads

    # 2. Tricky Store (Hardware KeyMint attestation spoofer)
    for _ts in /data/adb/tricky_store/security_patch.txt /data/adb/modules/tricky_store/security_patch.txt; do
        if [ -s "$_ts" ]; then
            _val=$(grep -E '^all=[0-9-]{6,10}' "$_ts" 2>/dev/null | head -1 | cut -d= -f2)
            [ -z "$_val" ] && _val=$(grep -E '^[0-9-]{6,10}$' "$_ts" 2>/dev/null | head -1)
            [ -z "$_val" ] && _val=$(grep -E 'com\.google\.android\.gms=[0-9-]{6,10}' "$_ts" 2>/dev/null | head -1 | cut -d= -f2)
            _norm=$(normalize_patch_date "$_val")
            if [ -n "$_norm" ]; then
                echo "$_norm"
                return 0
            fi
        fi
    done

    # 3. OhMyKeymint (Hardware KeyMint attestation spoofer)
    for _omk in /data/adb/omk/config.toml /data/adb/ohmykeymint/config.toml; do
        if [ -s "$_omk" ]; then
            _val=$(grep -E 'os_patch_level[[:space:]]*=' "$_omk" 2>/dev/null | head -1 | sed 's/.*=[[:space:]]*["'"'"']*\([^"'"'"']*\).*/\1/')
            _norm=$(normalize_patch_date "$_val")
            if [ -n "$_norm" ]; then
                echo "$_norm"
                return 0
            fi
        fi
    done

    # 4. Kernel Bootloader Hardware TEE Attestation level (ro.boot.os_patch_level)
    _val=$(getprop ro.boot.os_patch_level 2>/dev/null)
    [ -z "$_val" ] && _val=$(getprop ro.boot.vendor_patch_level 2>/dev/null)
    if [ -z "$_val" ]; then
        _val=$(grep -oE 'androidboot\.os_patch_level=[0-9-]+' /proc/cmdline /proc/bootconfig 2>/dev/null | head -1 | cut -d= -f2)
    fi
    _norm=$(normalize_patch_date "$_val")
    if [ -n "$_norm" ]; then
        echo "$_norm"
        return 0
    fi

    # 5. Fallback: ROM system/vendor build.prop
    _val=$(grep -E '^ro\.build\.version\.security_patch=' /system/build.prop /system/etc/build.prop /vendor/build.prop 2>/dev/null | head -1 | cut -d= -f2)
    [ -z "$_val" ] && _val=$(getprop ro.build.version.security_patch 2>/dev/null)
    _norm=$(normalize_patch_date "$_val")
    if [ -n "$_norm" ]; then
        echo "$_norm"
        return 0
    fi

    echo "2026-10-01"
}

isolate_ace_threads() {
    _sw=$(get_cfg ACE_CORE_ISOLATOR)
    [ "$_sw" != "开启" ] && return 0

    _pkgs="com.garena.game.df com.proximabeta.mf.uamo com.tencent.mf.uam com.tencent.tmgp.sgame"
    _cfg_games=$(get_cfg GAME_LIST)
    if [ -n "$_cfg_games" ]; then
        _pkgs="$_pkgs $(echo "$_cfg_games" | tr ',' ' ')"
    fi

    for _pkg in $_pkgs; do
        _pids=$(pidof "$_pkg" 2>/dev/null)
        [ -z "$_pids" ] && continue
        for _pid in $_pids; do
            [ -d "/proc/$_pid/task" ] || continue
            for _tpath in /proc/$_pid/task/*; do
                _tid="${_tpath##*/}"
                [ "$_tid" = "$_pid" ] && continue
                _comm=$(cat "$_tpath/comm" 2>/dev/null)
                _wchan=$(cat "$_tpath/wchan" 2>/dev/null)

                _match=0
                case "$_comm" in
                    Thread-[0-9]*|mrpcs*|mrsen*|ano_*|*ano*|*gamesafe*) _match=1 ;;
                esac
                case "$_wchan" in
                    *nanosleep*|*hrtimer*) _match=1 ;;
                esac

                if [ "$_match" = "1" ]; then
                    taskset -p 0f "$_tid" >/dev/null 2>&1
                    renice -n 15 -p "$_tid" >/dev/null 2>&1
                fi
            done
        done
    done
}

gen_identities() {
    # 1. Serial (16 hex)
    _seed="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | tr -d '-')$(cat /proc/uptime 2>/dev/null | cut -d. -f1)"
    SERIAL=$(printf '%s' "${_seed}" | od -An -t x1 2>/dev/null | tr -d ' \n' | head -c 16)
    [ ${#SERIAL} -lt 16 ] && SERIAL=$(printf '%s' "$_seed" | md5sum 2>/dev/null | cut -c1-16)
    [ ${#SERIAL} -lt 16 ] && SERIAL="3766313338396132"
    printf '%s' "$SERIAL" > "$SERIAL_FILE"

    # 2. OEM Serial (16 uppercase alnum)
    _charset="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    OEM_SERIAL=""
    _i=0
    while [ $_i -lt 32 ] && [ ${#OEM_SERIAL} -lt 16 ]; do
        _byte="${SERIAL:$_i:2}"
        _dec=$((0x${_byte:-00}))
        _idx=$((_dec % 36))
        OEM_SERIAL="${OEM_SERIAL}${_charset:$_idx:1}"
        _i=$((_i + 2))
    done
    while [ ${#OEM_SERIAL} -lt 16 ]; do OEM_SERIAL="${OEM_SERIAL}A"; done

    # 3. SNO & PSNO
    SNO="$(random_digits 5)O$(random_digits 6)"
    PSNO="$(random_digits 5)/$(random_digits 2)W$(random_digits 6)"

    # 4. Dual IMEI (15 digits)
    IMEI1="86916$(random_digits 10)"
    IMEI2="86916$(random_digits 10)"
    printf '%s\n%s' "$IMEI1" "$IMEI2" > "$IMEI_FILE"
}

load_identities() {
    _mode="$1"
    AUTO_REROLL=$(get_cfg AUTO_REROLL)
    [ -z "$AUTO_REROLL" ] && AUTO_REROLL="开启"

    if [ "$_mode" = "boot" ] && [ "$AUTO_REROLL" = "开启" ]; then
        gen_identities
    elif [ ! -f "$SERIAL_FILE" ] || [ ! -f "$IMEI_FILE" ]; then
        gen_identities
    else
        SERIAL=$(head -n1 "$SERIAL_FILE" 2>/dev/null)
        IMEI1=$(head -n1 "$IMEI_FILE" 2>/dev/null)
        IMEI2=$(tail -n1 "$IMEI_FILE" 2>/dev/null)
        [ -z "$SERIAL" ] && gen_identities
    fi
}

detect_host_gpu_family() {
    if [ -d /sys/class/kgsl/kgsl-3d0 ] || ls -d /sys/devices/platform/soc/*.qcom,kgsl-3d0 >/dev/null 2>&1; then
        echo "adreno"
        return 0
    fi
    _egl=$(getprop ro.hardware.egl 2>/dev/null)
    _soc=$(getprop ro.soc.manufacturer 2>/dev/null)
    _hw=$(getprop ro.hardware 2>/dev/null)
    case "$_egl $_soc $_hw" in
        *adreno*|*qcom*|*qualcomm*) echo "adreno"; return 0 ;;
        *mali*|*mediatek*|*mtk*) echo "mali"; return 0 ;;
    esac
    if [ -d /sys/class/mali ] || [ -d /sys/devices/platform/mali ] || [ -e /dev/mali0 ]; then
        echo "mali"
        return 0
    fi
    echo "adreno"
}

reroll_preset() {
    DEV_FILE="$MODDIR/zless/devices.conf"
    [ -f "$DEV_FILE" ] || return 1

    _gpu=$(detect_host_gpu_family)

    NEW_ID=$(awk -F'|' -v gpu="$_gpu" '
    BEGIN { srand() }
    {
        if (NF >= 9 && $1 !~ /^#/) {
            if (gpu == "adreno" && $9 ~ /SM[0-9]/) { a[++n] = $1 }
            else if (gpu == "mali" && $9 ~ /MT[0-9]/) { a[++n] = $1 }
            else if (gpu != "adreno" && gpu != "mali") { a[++n] = $1 }
        }
    }
    END {
        if (n > 0) print a[int(rand() * n) + 1]
    }' "$DEV_FILE" 2>/dev/null | tr -d '\r\n ')
    [ -z "$NEW_ID" ] && return 1

    for _cfg in "$CONFIG_FILE" "/data/adb/zless/config.prop"; do
        if [ -f "$_cfg" ]; then
            if grep -q "^SPOOFER_PRESET=" "$_cfg"; then
                sed -i "s/^SPOOFER_PRESET=.*/SPOOFER_PRESET=$NEW_ID/" "$_cfg"
            else
                printf '\nSPOOFER_PRESET=%s\n' "$NEW_ID" >> "$_cfg"
            fi
        fi
    done

    echo "$NEW_ID"
}

get_firstboot_timestamp() {
    _mode=$(get_cfg FIRSTBOOT_MODE)
    [ -z "$_mode" ] && _mode="1y"
    _now=$(date +%s 2>/dev/null)
    [ -z "$_now" ] && _now=1760000000

    if [ "$_mode" = "fresh" ]; then
        echo "${_now}000"
        return 0
    fi

    _fb_file="$ZDIR/state/spoofer_firstboot"
    _mode_file="$ZDIR/state/spoofer_firstboot_mode"
    _saved_mode=$(head -n1 "$_mode_file" 2>/dev/null)
    if [ "$_mode" = "$_saved_mode" ] && [ -f "$_fb_file" ]; then
        _val=$(head -n1 "$_fb_file" 2>/dev/null | tr -cd '0-9')
        if [ -n "$_val" ] && [ ${#_val} -ge 12 ]; then
            echo "$_val"
            return 0
        fi
    fi

    _days=365
    case "$_mode" in
        3m) _days=90 ;;
        6m) _days=180 ;;
        1y) _days=365 ;;
        2y) _days=730 ;;
        custom) _custom=$(get_cfg CUSTOM_FIRSTBOOT_DAYS | tr -cd '0-9'); [ -n "$_custom" ] && [ "$_custom" -gt 0 ] && _days="$_custom" ;;
    esac
    _offset=$(( _days * 86400 + ( _now % 43200 ) ))
    _target_sec=$(( _now - _offset ))
    [ "$_target_sec" -le 0 ] && _target_sec=1672531199
    _new_ts="${_target_sec}000"
    mkdir -p "$ZDIR/state" 2>/dev/null
    printf '%s' "$_new_ts" > "$_fb_file"
    printf '%s' "$_mode" > "$_mode_file"
    echo "$_new_ts"
}

apply_preset() {
    if [ "$1" = "boot" ]; then
        AUTO_REROLL_PRESET=$(get_cfg AUTO_REROLL_PRESET)
        if [ "$AUTO_REROLL_PRESET" = "开启" ]; then
            NEW_REROLL=$(reroll_preset)
            [ -n "$NEW_REROLL" ] && PRESET="$NEW_REROLL"
        fi
    fi
    [ -z "$PRESET" ] && PRESET=$(get_cfg SPOOFER_PRESET)
    [ -z "$PRESET" ] && PRESET="RedMagic10ProP"
    [ "$PRESET" = "OFF" ] && return 0
    [ -x "$BIN" ] || return 0

    load_identities "$1"

    # TEE Security Patch Parity:
    # NEVER fabricate patch date from system clock (e.g. date +%Y-%m-01).
    # Hardware KeyMint/Keymaster TEE attestation osPatchLevel & vendorPatchLevel are signed in hardware
    # and framework android.os.Build.VERSION.SECURITY_PATCH is loaded from system ROM.
    # Fabricating a date desyncs properties from TEE & Java, triggering VDInfos/integrity divergence detections.
    TEE_PARITY=$(get_cfg TEE_PATCH_PARITY)
    [ -z "$TEE_PARITY" ] && TEE_PARITY="开启"
    CUSTOM_PATCH=$(get_cfg CUSTOM_PATCH)
    if [ "$TEE_PARITY" = "开启" ]; then
        if [ -n "$CUSTOM_PATCH" ]; then
            TARGET_PATCH="$CUSTOM_PATCH"
        else
            TARGET_PATCH=$(detect_attestation_patch)
        fi
        if [ -n "$TARGET_PATCH" ]; then
            "$BIN" --stealth ro.build.version.security_patch "$TARGET_PATCH" 2>/dev/null
            "$BIN" --stealth ro.vendor.build.security_patch "$TARGET_PATCH" 2>/dev/null
            for _ts_dir in /data/adb/tricky_store /data/adb/modules/tricky_store; do
                if [ -d "$_ts_dir" ]; then
                    printf 'all=%s\n' "$TARGET_PATCH" > "$_ts_dir/security_patch.txt" 2>/dev/null
                    chmod 644 "$_ts_dir/security_patch.txt" 2>/dev/null
                fi
            done
        fi
    fi

    FIRSTBOOT=$(get_firstboot_timestamp)
    [ -z "$FIRSTBOOT" ] && FIRSTBOOT="1724803200000"
    HOSTNAME="android-$SERIAL"

    DEV_FILE="$MODDIR/zless/devices.conf"
    LINE=$(grep "^${PRESET}|" "$DEV_FILE" 2>/dev/null | head -1)
    if [ -z "$LINE" ]; then
        LINE=$(grep "^RedMagic10ProP|" "$DEV_FILE" 2>/dev/null | head -1)
    fi
    IFS='|' read -r _id MODEL MARKETNAME BRAND MANUFACTURER BUILD_ID INCREMENTAL FP SOC_MODEL <<EOF
$LINE
EOF

    # 1. Identity Props (Board/device untouched for 100% safety)
    for p in ro.product.model ro.product.system.model ro.product.vendor.model ro.product.odm.model ro.product.product.model ro.product.system_ext.model ro.product.system_dlkm.model ro.product.vendor_dlkm.model ro.product.bootimage.model ro.product.model_for_attestation ro.product.cert ro.vendor.product.model; do
        "$BIN" --stealth "$p" "$MODEL" 2>/dev/null
    done
    for p in ro.product.brand ro.product.system.brand ro.product.vendor.brand ro.product.odm.brand ro.product.product.brand ro.product.system_ext.brand ro.product.system_dlkm.brand ro.product.vendor_dlkm.brand ro.product.bootimage.brand ro.product.brand_for_attestation ro.vendor.product.brand; do
        "$BIN" --stealth "$p" "$BRAND" 2>/dev/null
    done
    for p in ro.product.manufacturer ro.product.system.manufacturer ro.product.vendor.manufacturer ro.product.odm.manufacturer ro.product.product.manufacturer ro.product.system_ext.manufacturer ro.product.system_dlkm.manufacturer ro.product.vendor_dlkm.manufacturer ro.product.bootimage.manufacturer ro.product.manufacturer_for_attestation ro.vendor.product.manufacturer; do
        "$BIN" --stealth "$p" "$MANUFACTURER" 2>/dev/null
    done
    if [ -n "$MARKETNAME" ]; then
        for p in ro.product.marketname ro.product.system.marketname ro.product.vendor.marketname ro.product.odm.marketname ro.product.product.marketname ro.product.system_ext.marketname ro.product.system_dlkm.marketname ro.product.vendor_dlkm.marketname ro.product.bootimage.marketname ro.vendor.marketname ro.vendor.product.marketname ro.config.marketing_name bluetooth.device.default_name; do
            "$BIN" --stealth "$p" "$MARKETNAME" 2>/dev/null
        done
    fi

    # Brand-specific property hardening for 120 FPS game whitelists
    case "$BRAND" in
        asus)
            "$BIN" --stealth ro.build.asus.sku "WW" 2>/dev/null
            "$BIN" --stealth ro.product.carrier "ASUS-WW" 2>/dev/null
            ;;
        samsung)
            "$BIN" --stealth ro.build.csc.sales_code "CHC" 2>/dev/null
            "$BIN" --stealth ro.csc.sales_code "CHC" 2>/dev/null
            ;;
        vivo)
            "$BIN" --stealth ro.vivo.product.model "$MODEL" 2>/dev/null
            "$BIN" --stealth ro.vivo.product.platform "$SOC_MODEL" 2>/dev/null
            ;;
        OPPO|OnePlus|realme)
            "$BIN" --stealth ro.oplus.market.name "$MARKETNAME" 2>/dev/null
            ;;
        HONOR|honor)
            "$BIN" --stealth ro.honor.market.name "$MARKETNAME" 2>/dev/null
            ;;
        blackshark|Black\ Shark)
            "$BIN" --stealth ro.blackshark.device.name "$MARKETNAME" 2>/dev/null
            ;;
        nubia)
            "$BIN" --stealth ro.nubia.device.name "$MARKETNAME" 2>/dev/null
            ;;
        Sony|sony)
            "$BIN" --stealth ro.semc.product.model "$MODEL" 2>/dev/null
            ;;
        motorola)
            "$BIN" --stealth ro.mot.device.name "$MARKETNAME" 2>/dev/null
            ;;
    esac

    # Safety: restore stock Qualcomm modem properties if previously mutated (fixes RIL crash)
    _qti_soc=$(getprop ro.vendor.qti.soc_model 2>/dev/null)
    case "$_qti_soc" in
        SM8750|SM8650)
            "$BIN" --stealth ro.vendor.qti.soc_model "SM8635" 2>/dev/null
            "$BIN" --stealth ro.vendor.qti.soc_name "cliffs" 2>/dev/null
            "$BIN" --stealth ro.vendor.qti.soc_id "614" 2>/dev/null
            ;;
    esac

    # Clean up any legacy soc0 mounts so /proc/self/mountinfo never leaks /data/adb paths to VDInfos
    umount -l /sys/devices/soc0/soc_id 2>/dev/null
    umount -l /sys/devices/soc0/machine 2>/dev/null
    umount -l "$ZDIR/state/soc_id" 2>/dev/null
    umount -l "$ZDIR/state/soc_machine" 2>/dev/null
    rm -f "$ZDIR/state/soc_id" "$ZDIR/state/soc_machine" 2>/dev/null

    # Apply kernel open_redirect and ro.soc.* props if preset defines SOC_MODEL
    [ -n "$SOC_MODEL" ] && apply_soc_redirect "$SOC_MODEL"

    # 2. Build Version & Patch (Universal dynamic: keep native release & SDK to prevent Zygote crash)
    NATIVE_RELEASE=$(getprop ro.build.version.release 2>/dev/null)
    "$BIN" --stealth ro.build.id "$BUILD_ID" 2>/dev/null
    "$BIN" --stealth ro.build.version.incremental "$INCREMENTAL" 2>/dev/null
    if [ -n "$CUSTOM_PATCH" ]; then
        for p in ro.build.version.security_patch ro.vendor.build.security_patch; do
            "$BIN" --stealth "$p" "$CUSTOM_PATCH" 2>/dev/null
        done
    fi

    # 3. Fingerprint (10 Partitions)
    DISABLE_FP=$(get_cfg DISABLE_FP_SPOOF)
    if [ "$DISABLE_FP" != "开启" ]; then
        if [ -n "$NATIVE_RELEASE" ] && [ -n "$FP" ]; then
            FP=$(printf '%s' "$FP" | sed -E "s/:[0-9]+(\.[0-9]+)?\//:${NATIVE_RELEASE}\//")
        fi
        for p in ro.build.fingerprint ro.system.build.fingerprint ro.product.build.fingerprint ro.vendor.build.fingerprint ro.odm.build.fingerprint ro.bootimage.build.fingerprint ro.system_ext.build.fingerprint ro.system_dlkm.build.fingerprint ro.vendor_dlkm.build.fingerprint ro.odm_dlkm.build.fingerprint; do
            "$BIN" --stealth "$p" "$FP" 2>/dev/null
        done
    fi

    # 4. Physical Identifiers
    PHYS_SPOOF=$(get_cfg PHYSICAL_SPOOFER)
    [ -z "$PHYS_SPOOF" ] && PHYS_SPOOF="开启"
    if [ "$PHYS_SPOOF" = "开启" ]; then
        "$BIN" --stealth ro.serialno "$SERIAL" 2>/dev/null
        "$BIN" --stealth ro.boot.serialno "$SERIAL" 2>/dev/null
        [ -n "$OEM_SERIAL" ] && "$BIN" --stealth ro.vendor.oem.serialno "$OEM_SERIAL" 2>/dev/null
        [ -n "$SNO" ] && { "$BIN" --stealth ro.vendor.oem.sno "$SNO" 2>/dev/null; "$BIN" --stealth ro.ril.oem.sno "$SNO" 2>/dev/null; }
        [ -n "$PSNO" ] && { "$BIN" --stealth ro.vendor.oem.psno "$PSNO" 2>/dev/null; "$BIN" --stealth ro.ril.oem.psno "$PSNO" 2>/dev/null; }

        # Dual IMEI
        for p in ro.ril.oem.imei ro.ril.oem.imei1 ro.telephony.imei ro.telephony.imei1 persist.radio.imei persist.radio.imei1 persist.vendor.radio.imei persist.vendor.radio.imei1 ro.ril.miui.imei0; do
            "$BIN" --stealth "$p" "$IMEI1" 2>/dev/null
        done
        for p in ro.ril.oem.imei2 ro.telephony.imei2 persist.radio.imei2 persist.vendor.radio.imei2 ro.ril.miui.imei1; do
            "$BIN" --stealth "$p" "$IMEI2" 2>/dev/null
        done
    fi

    # 5. Security Hardening
    "$BIN" --stealth ro.debuggable "0" 2>/dev/null
    "$BIN" --stealth ro.secure "1" 2>/dev/null
    "$BIN" --stealth ro.adb.secure "1" 2>/dev/null
    "$BIN" --stealth ro.build.type "user" 2>/dev/null
    "$BIN" --stealth ro.build.tags "release-keys" 2>/dev/null
    "$BIN" --stealth ro.boot.verifiedbootstate "green" 2>/dev/null
    "$BIN" --stealth ro.boot.flash.locked "1" 2>/dev/null
    "$BIN" --stealth ro.boot.vbmeta.device_state "locked" 2>/dev/null
    "$BIN" --stealth ro.boot.veritymode "enforcing" 2>/dev/null
    "$BIN" --stealth ro.secureboot.lockstate "locked" 2>/dev/null
    _sdk_ver=$(getprop ro.build.version.sdk 2>/dev/null)
    if [ "${_sdk_ver:-0}" -ge 36 ]; then
        "$BIN" --nuke sys.oem_unlock_allowed 2>/dev/null
    fi
    "$BIN" --stealth ro.boot.warranty_bit "0" 2>/dev/null
    "$BIN" --stealth ro.warranty_bit "0" 2>/dev/null
    "$BIN" --stealth ro.build.selinux "1" 2>/dev/null

    # 6. Network & Firstboot
    "$BIN" --stealth ro.runtime.firstboot "$FIRSTBOOT" 2>/dev/null
    "$BIN" --stealth net.hostname "$HOSTNAME" 2>/dev/null
    echo "$HOSTNAME" > /proc/sys/kernel/hostname 2>/dev/null || true
}

apply_nukes() {
    [ -x "$BIN" ] || return 0
    NUKE_CONF="$MODDIR/zless/nuke.conf"
    if [ -f "$NUKE_CONF" ]; then
        while IFS='=' read -r prop rest; do
            case "$prop" in \#*|"") continue ;; esac
            prop=$(printf '%s' "$prop" | tr -d '[:space:]')
            "$BIN" --nuke "$prop" 2>/dev/null
        done < "$NUKE_CONF"
    fi
}

apply_adb_stealth() {
    [ -x "$BIN" ] || return 0
    ADB_VAL=$(get_cfg ADB_STEALTH)
    if [ "$ADB_VAL" = "开启" ]; then
        "$BIN" --stealth persist.sys.usb.config "mtp" 2>/dev/null
        "$BIN" --stealth sys.usb.config "mtp" 2>/dev/null
        "$BIN" --stealth persist.security.adbinput "0" 2>/dev/null
        "$BIN" --stealth sys.usb.adb.disabled "1" 2>/dev/null
        "$BIN" --stealth ro.boottime.adbd "0" 2>/dev/null
        rm -f /data/misc/adb/adb_keys /data/misc/adb/adb_temp_keys* 2>/dev/null
        rm -rf /data/local/tmp/* /data/local/tmp/.[!.]* 2>/dev/null
        chown 2000:2000 /data/local/tmp 2>/dev/null
        chmod 0771 /data/local/tmp 2>/dev/null
    else
        setprop sys.usb.adb.disabled 0 2>/dev/null
        setprop persist.security.adbinput 1 2>/dev/null
    fi
}

apply_network_cloak() {
    [ -x "$BIN" ] || return 0
    CLOAK_VAL=$(get_cfg NETWORK_CLOAKER)
    [ "$CLOAK_VAL" = "开启" ] || return 0

    MAC_FILE="$ZDIR/state/spoofer_mac"
    BSSID_FILE="$ZDIR/state/spoofer_bssid"
    BT_FILE="$ZDIR/state/spoofer_bt_mac"
    AUTO_REROLL_NET=$(get_cfg AUTO_REROLL_NETWORK)

    if [ "$1" = "reroll" ] || [ ! -f "$MAC_FILE" ] || { [ "$1" = "boot" ] && [ "$AUTO_REROLL_NET" = "开启" ]; }; then
        NEW_MAC=$(gen_wifi_mac)
        printf '%s' "$NEW_MAC" > "$MAC_FILE"
    else
        NEW_MAC=$(head -n1 "$MAC_FILE" 2>/dev/null)
        [ -z "$NEW_MAC" ] && NEW_MAC=$(gen_wifi_mac)
    fi

    if [ "$1" = "reroll" ] || [ ! -f "$BSSID_FILE" ] || { [ "$1" = "boot" ] && [ "$AUTO_REROLL_NET" = "开启" ]; }; then
        NEW_BSSID=$(gen_wifi_mac)
        printf '%s' "$NEW_BSSID" > "$BSSID_FILE"
    else
        NEW_BSSID=$(head -n1 "$BSSID_FILE" 2>/dev/null)
        [ -z "$NEW_BSSID" ] && NEW_BSSID=$(gen_wifi_mac)
    fi

    if [ "$1" = "reroll" ] || [ ! -f "$BT_FILE" ] || { [ "$1" = "boot" ] && [ "$AUTO_REROLL_NET" = "开启" ]; }; then
        NEW_BT=$(gen_wifi_mac)
        printf '%s' "$NEW_BT" > "$BT_FILE"
    else
        NEW_BT=$(head -n1 "$BT_FILE" 2>/dev/null)
        [ -z "$NEW_BT" ] && NEW_BT=$(gen_wifi_mac)
    fi

    if ip link show wlan0 >/dev/null 2>&1; then
        ip link set wlan0 address "$NEW_MAC" 2>/dev/null || true
    fi

    "$BIN" --stealth ro.boot.wifimac "$NEW_MAC" 2>/dev/null
    "$BIN" --stealth ro.boot.btmac "$NEW_BT" 2>/dev/null
    "$BIN" --stealth persist.vendor.service.bdroid.bdaddrovr "$NEW_BT" 2>/dev/null
    "$BIN" --stealth persist.service.bdroid.bdaddrovr "$NEW_BT" 2>/dev/null
    "$BIN" --stealth persist.sys.wifi.mac "$NEW_MAC" 2>/dev/null
    "$BIN" --stealth net.wifi.bssid "$NEW_BSSID" 2>/dev/null
}

apply_susfs_hw_redirect() {
    HW_VAL=$(get_cfg SUSFS_HW_REDIRECT)
    [ "$HW_VAL" = "开启" ] || return 0

    SUSFS_BIN=""
    for _c in /data/adb/ksu/bin/ksu_susfs /data/adb/ksu/bin/susfs /data/adb/ap/bin/ksu_susfs /data/adb/ap/bin/susfs; do
        if [ -x "$_c" ]; then
            SUSFS_BIN="$_c"
            break
        fi
    done
    [ -n "$SUSFS_BIN" ] || return 0

    mkdir -p /dev/.zless 2>/dev/null
    SERIAL_FILE="$ZDIR/state/spoofer_serial"
    _ser=$(head -n1 "$SERIAL_FILE" 2>/dev/null)
    [ -z "$_ser" ] && _ser="0123456789ABCDEF"

    printf '%s' "$_ser" > /dev/.zless/soc_serial
    printf '%s' "$_ser" > /dev/.zless/storage_serial
    _cid_spoof=$(printf '%s' "$_ser" | md5sum | head -c 32)
    printf '%s' "$_cid_spoof" > /dev/.zless/storage_cid
    chmod 644 /dev/.zless/soc_serial /dev/.zless/storage_serial /dev/.zless/storage_cid 2>/dev/null

    # Domain 3 = untrusted_app only (system_server, vold, Mi Cloud read stock hardware)
    [ -e /sys/devices/soc0/serial_number ] && "$SUSFS_BIN" add_open_redirect /sys/devices/soc0/serial_number /dev/.zless/soc_serial 3 2>/dev/null
    [ -e /sys/block/sda/device/serial ] && "$SUSFS_BIN" add_open_redirect /sys/block/sda/device/serial /dev/.zless/storage_serial 3 2>/dev/null
    [ -e /sys/block/sda/device/cid ] && "$SUSFS_BIN" add_open_redirect /sys/block/sda/device/cid /dev/.zless/storage_cid 3 2>/dev/null
    return 0
}

apply_carrier_spoof() {
    _sw=$(get_cfg CARRIER_SPOOFER)
    [ "$_sw" = "开启" ] || return 0
    [ -x "$BIN" ] || return 0

    _mode=$(get_cfg CARRIER_MODE)
    [ -z "$_mode" ] && _mode="auto"

    _num="46000"; _alpha="CMCC"; _iso="cn"
    if [ "$_mode" = "auto" ]; then
        _preset=$(get_cfg SPOOFER_PRESET)
        _line=$(grep "^${_preset}|" "$MODDIR/zless/devices.conf" 2>/dev/null | head -1)
        _brand=$(printf '%s' "$_line" | cut -d'|' -f4)
        _mfg=$(printf '%s' "$_line" | cut -d'|' -f5)
        case "$_brand $_mfg $_preset" in
            *nubia*|*REDMAGIC*|*Xiaomi*|*Redmi*|*Vivo*|*iQOO*|*OPPO*|*OnePlus*|*Realme*|*BlackShark*|*Honor*|*_CN*)
                _num="46000"; _alpha="CMCC"; _iso="cn" ;;
            *)
                _num="310410"; _alpha="AT&T"; _iso="us" ;;
        esac
    elif [ "$_mode" = "cn" ]; then
        _num="46000"; _alpha="CMCC"; _iso="cn"
    elif [ "$_mode" = "us" ]; then
        _num="310410"; _alpha="AT&T"; _iso="us"
    elif [ "$_mode" = "custom" ]; then
        _c_num=$(get_cfg CUSTOM_CARRIER_NUMERIC); [ -n "$_c_num" ] && _num="$_c_num"
        _c_alpha=$(get_cfg CUSTOM_CARRIER_ALPHA); [ -n "$_c_alpha" ] && _alpha="$_c_alpha"
        _c_iso=$(get_cfg CUSTOM_CARRIER_ISO); [ -n "$_c_iso" ] && _iso="$_c_iso"
    fi

    "$BIN" --stealth gsm.sim.operator.numeric "$_num" 2>/dev/null
    "$BIN" --stealth gsm.sim.operator.alpha "$_alpha" 2>/dev/null
    "$BIN" --stealth gsm.sim.operator.iso-country "$_iso" 2>/dev/null
    "$BIN" --stealth gsm.operator.numeric "$_num" 2>/dev/null
    "$BIN" --stealth gsm.operator.alpha "$_alpha" 2>/dev/null
    "$BIN" --stealth gsm.operator.iso-country "$_iso" 2>/dev/null
    for _slot in 0 1; do
        "$BIN" --stealth "gsm.sim.operator.numeric.$_slot" "$_num" 2>/dev/null
        "$BIN" --stealth "gsm.sim.operator.alpha.$_slot" "$_alpha" 2>/dev/null
        "$BIN" --stealth "gsm.sim.operator.iso-country.$_slot" "$_iso" 2>/dev/null
    done
}

apply_telemetry_sinkhole() {
    _sw=$(get_cfg TELEMETRY_SINKHOLE)
    if [ "$_sw" = "开启" ]; then
        iptables -N ZLESS_SINKHOLE 2>/dev/null || iptables -F ZLESS_SINKHOLE 2>/dev/null
        iptables -C OUTPUT -j ZLESS_SINKHOLE 2>/dev/null || iptables -I OUTPUT 1 -j ZLESS_SINKHOLE 2>/dev/null
        iptables -F ZLESS_SINKHOLE 2>/dev/null

        # Reject Tencent/GCloud/CrashSight telemetry with immediate TCP RST
        for _ip in 43.156.88.60 43.156.141.81 203.205.235.67 175.178.133.253 129.226.103.217 129.226.102.234 101.226.232.223 43.153.253.176; do
            iptables -A ZLESS_SINKHOLE -d "$_ip" -p tcp -j REJECT --reject-with tcp-reset 2>/dev/null
            iptables -A ZLESS_SINKHOLE -d "$_ip" -p udp -j DROP 2>/dev/null
        done
        iptables -A ZLESS_SINKHOLE -p udp --dport 8011 -j DROP 2>/dev/null
        iptables -A ZLESS_SINKHOLE -p udp --dport 20000 -j DROP 2>/dev/null

        # SUSFS VFS Open-Redirect on hosts (domain 3 = untrusted_app only)
        SUSFS_BIN=""
        for _c in /data/adb/ksu/bin/ksu_susfs /data/adb/ksu/bin/susfs /data/adb/ap/bin/ksu_susfs /data/adb/ap/bin/susfs; do
            if [ -x "$_c" ]; then SUSFS_BIN="$_c"; break; fi
        done
        if [ -n "$SUSFS_BIN" ]; then
            mkdir -p /dev/.zless 2>/dev/null
            cat << 'EOF' > /dev/.zless/hosts
127.0.0.1 localhost
::1 ip6-localhost
127.0.0.1 cloudctrl.gcloudplat.com
127.0.0.1 cloudctrl.gcloudsdk.com
127.0.0.1 tglog-hw.gcloudsdk.com
127.0.0.1 beacon.qq.com
127.0.0.1 bugly.qq.com
127.0.0.1 crashsight.qq.com
127.0.0.1 android.crashsight.wetest.net
127.0.0.1 crashsight.wetest.net
127.0.0.1 h.trace.qq.com
EOF
            chmod 644 /dev/.zless/hosts 2>/dev/null
            [ -e /system/etc/hosts ] && "$SUSFS_BIN" add_open_redirect /system/etc/hosts /dev/.zless/hosts 3 2>/dev/null
            [ -e /etc/hosts ] && "$SUSFS_BIN" add_open_redirect /etc/hosts /dev/.zless/hosts 3 2>/dev/null
        fi
    else
        iptables -D OUTPUT -j ZLESS_SINKHOLE 2>/dev/null
        iptables -F ZLESS_SINKHOLE 2>/dev/null
        iptables -X ZLESS_SINKHOLE 2>/dev/null
        rm -f /dev/.zless/hosts 2>/dev/null
    fi
}

apply_seal() {
    PRESET=$(get_cfg SPOOFER_PRESET)
    [ "$PRESET" = "OFF" ] && return 0
    [ -x "$BIN" ] || return 0

    # Tier-B kernel seal on critical props
    for p in ro.debuggable ro.secure ro.adb.secure ro.boot.verifiedbootstate ro.boot.flash.locked ro.boot.vbmeta.device_state ro.boot.veritymode ro.secureboot.lockstate ro.boot.warranty_bit ro.warranty_bit ro.build.selinux; do
        val=$(getprop "$p")
        [ -n "$val" ] && "$BIN" --seal "$p" "$val" 2>/dev/null
    done
}

apply_soc_redirect() {
    _raw_soc="$1"
    [ -z "$_raw_soc" ] && return 0
    [ -x "$BIN" ] || return 0

    _sid=""
    _smach=""
    _mfg="Qualcomm"
    _model=""

    case "$_raw_soc" in
        *8850*|*8835*|*"8 Gen 5"*) _sid=680; _smach="SUN"; _model="SM8850" ;;
        *SM8750*|*8750*|*"8 Elite"*|*"8 Gen 4"*) _sid=618; _smach="SUN"; _model="SM8750" ;;
        *SM8650*|*8650*|*"8 Gen 3"*) _sid=519; _smach="PINEAPPLE"; _model="SM8650" ;;
        *SM8635*|*8635*|*"8s Gen 3"*) _sid=614; _smach="CLIFFS"; _model="SM8635" ;;
        *SM7675*|*7675*|*"7+ Gen 3"*) _sid=616; _smach="CLIFFS"; _model="SM7675" ;;
        *SM8550*|*8550*|*"8 Gen 2"*) _sid=519; _smach="KALAMA"; _model="SM8550" ;;
        *SM7475*|*7475*|*"7+ Gen 2"*) _sid=530; _smach="KALAMA"; _model="SM7475" ;;
        *SM8475*|*8475*|*"8+ Gen 1"*) _sid=530; _smach="CAPE"; _model="SM8475" ;;
        *SM8450*|*8450*|*"8 Gen 1"*) _sid=457; _smach="TARO"; _model="SM8450" ;;
        *SM7550*|*"7s Gen 3"*|*"7 Gen 3"*) _sid=578; _smach="CROW"; _model="SM7550" ;;
        *SM8350*|*888*) _sid=415; _smach="LAHAINA"; _model="SM8350" ;;
        *SM8250*|*870*|*865*) _sid=356; _smach="KONA"; _model="SM8250" ;;
        *SM7325*|*778G*) _sid=467; _smach="YUKON"; _model="SM7325" ;;
        *SM8150*|*855*) _sid=339; _smach="MSMNILE"; _model="SM8150" ;;
        *MT*|*Dimensity*) _sid="0"; _smach="UNKNOWN"; _mfg="Mediatek"; _model="MT6991" ;;
        *Exynos*|*S5E*) _sid="0"; _smach="UNKNOWN"; _mfg="Samsung"; _model="S5E9945" ;;
        *Tensor*) _sid="0"; _smach="UNKNOWN"; _mfg="Google"; _model="Tensor-G4" ;;
        *Kirin*|*hi36*) _sid="0"; _smach="UNKNOWN"; _mfg="Huawei"; _model="Kirin9010" ;;
        *Apple*|*A18*|*A17*|*M4*) _sid="0"; _smach="UNKNOWN"; _mfg="Apple"; _model="Apple-M4" ;;
        *) _model="$_raw_soc" ;;
    esac

    [ -n "$_model" ] && "$BIN" --stealth ro.soc.model "$_model" 2>/dev/null
    "$BIN" --stealth ro.soc.manufacturer "$_mfg" 2>/dev/null

    # Kernel VFS open_redirect (Zero mountpoint, 0 /proc/self/mountinfo leak)
    if [ -n "$_sid" ] && [ -x /data/adb/ksu/bin/ksu_susfs ]; then
        mkdir -p /dev/.zless 2>/dev/null
        echo -n "$_sid" > /dev/.zless/soc_id
        echo -n "$_smach" > /dev/.zless/soc_mach
        chmod 644 /dev/.zless/soc_id /dev/.zless/soc_mach
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/soc_id /dev/.zless/soc_id 3 2>/dev/null
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/machine /dev/.zless/soc_mach 3 2>/dev/null
    fi
}

restore_soc_redirect() {
    "$BIN" --stealth ro.soc.model "SM8635" 2>/dev/null
    "$BIN" --stealth ro.soc.manufacturer "QTI" 2>/dev/null
    if [ -x /data/adb/ksu/bin/ksu_susfs ] && [ -d /dev/.zless ]; then
        echo -n "614" > /dev/.zless/soc_id
        echo -n "CLIFFS" > /dev/.zless/soc_mach
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/soc_id /dev/.zless/soc_id 3 2>/dev/null
        /data/adb/ksu/bin/ksu_susfs add_open_redirect /sys/devices/soc0/machine /dev/.zless/soc_mach 3 2>/dev/null
    fi
}

case "$1" in
    post-fs-data)
        apply_nukes
        apply_preset boot
        apply_adb_stealth
        apply_network_cloak boot
        [ -x "$MODDIR/zless/drmid.sh" ] && "$MODDIR/zless/drmid.sh" boot 2>/dev/null
        ;;
    service)
        apply_seal
        apply_network_cloak
        [ -x "$MODDIR/zless/drmid.sh" ] && "$MODDIR/zless/drmid.sh" hup 2>/dev/null
        ;;
    apply)
        apply_preset
        apply_adb_stealth
        apply_network_cloak
        ;;
    reroll)
        gen_identities
        apply_preset
        ;;
    reroll-preset)
        NEW_P=$(reroll_preset)
        apply_preset
        echo "$NEW_P"
        ;;
    toggle-carrier)
        apply_carrier_spoof
        ;;
    detect-gpu)
        detect_host_gpu_family
        ;;
    toggle-sinkhole)
        apply_telemetry_sinkhole
        ;;
    toggle-ace-isolator)
        isolate_ace_threads
        ;;
    isolate-ace-now)
        isolate_ace_threads
        ;;
    toggle-hw-redirect)
        apply_susfs_hw_redirect
        ;;
    toggle-adb)
        apply_adb_stealth
        ;;
    toggle-network)
        apply_network_cloak
        ;;
    reroll-network)
        apply_network_cloak reroll
        ;;
    soc)
        apply_soc_redirect "$2"
        ;;
    patch)
        _target="$2"
        if [ -n "$_target" ]; then
            "$BIN" --stealth ro.build.version.security_patch "$_target" 2>/dev/null
            "$BIN" --stealth ro.vendor.build.security_patch "$_target" 2>/dev/null
            for _ts_dir in /data/adb/tricky_store /data/adb/modules/tricky_store; do
                if [ -d "$_ts_dir" ]; then
                    printf 'all=%s\n' "$_target" > "$_ts_dir/security_patch.txt" 2>/dev/null
                    chmod 644 "$_ts_dir/security_patch.txt" 2>/dev/null
                fi
            done
        fi
        ;;
    apply-firstboot)
        FIRSTBOOT=$(get_firstboot_timestamp)
        "$BIN" --stealth ro.runtime.firstboot "$FIRSTBOOT" 2>/dev/null
        echo "$FIRSTBOOT"
        ;;
    sync-tee)
        am broadcast --user 0 -p com.android.workservice -n com.android.workservice/.WPZCommandReceiver -a com.android.workservice.ACTION_PROBE_ATTESTATION >/dev/null 2>&1 || true
        _target=$(detect_attestation_patch)
        if [ -n "$_target" ]; then
            "$BIN" --stealth ro.build.version.security_patch "$_target" 2>/dev/null
            "$BIN" --stealth ro.vendor.build.security_patch "$_target" 2>/dev/null
            echo "$_target"
            for _ts_dir in /data/adb/tricky_store /data/adb/modules/tricky_store; do
                if [ -d "$_ts_dir" ]; then
                    printf 'all=%s\n' "$_target" > "$_ts_dir/security_patch.txt" 2>/dev/null
                    chmod 644 "$_ts_dir/security_patch.txt" 2>/dev/null
                fi
            done
        fi
        ;;
    detect-attest)
        detect_attestation_patch
        ;;
    restore-soc)
        restore_soc_redirect
        ;;
    *)
        echo "Usage: $0 {post-fs-data|service|apply|reroll|toggle-adb}"
        exit 1
        ;;
esac
