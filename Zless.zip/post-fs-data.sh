#!/system/bin/sh
# Zless Unified - hardening awal persist/nvdata (dari modul Tenc), gated oleh 权限加固

MODDIR=${0%/*}
. "$MODDIR/zless/common.sh"

# Clean up any legacy soc0 mounts so /proc/self/mountinfo never leaks /data/adb paths to VDInfos
umount -l /sys/devices/soc0/soc_id 2>/dev/null
umount -l /sys/devices/soc0/machine 2>/dev/null

# Universal Spoofer Engine (Nukes + Identity + TEE Sync + ADB Stealth)
[ -x "$MODDIR/zless/spoofer.sh" ] && "$MODDIR/zless/spoofer.sh" post-fs-data 2>/dev/null

[ "$(get_switch 权限加固)" = "开启" ] || exit 0

chmod 700 /mnt/vendor/persist/data 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/PRODUCT_INFO 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/WIFI 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/BT_Addr 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/ETHERNET 2>/dev/null
# Directories retain search permission; only regular files are restricted.
for tree in /mnt/vendor/nvdata/md/NVRAM/NVD_IMEI /mnt/vendor/nvdata/md/NVRAM/CALIBRAT; do
    find "$tree" -type d -exec chmod 750 {} \; 2>/dev/null
    find "$tree" -type f -exec chmod 660 {} \; 2>/dev/null
done
