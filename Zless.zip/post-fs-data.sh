#!/system/bin/sh
# Zless Unified - hardening awal persist/nvdata (dari modul Tenc), gated oleh 权限加固

_sus_bin=""
for _b in /data/adb/ksu/bin/ksu_susfs /data/adb/ksu/bin/susfs /data/adb/ap/bin/ksu_susfs /data/adb/ap/bin/susfs; do
    if [ -x "$_b" ]; then _sus_bin="$_b"; break; fi
done
if [ -n "$_sus_bin" ]; then
    # Sembunyikan folder root dan xbin dari syscall game agar merespons ENOENT bukan EACCES
    for _target in "/data/adb" "/data/adb/ksud" "/system/xbin"; do
        "$_sus_bin" add_sus_path_loop "$_target" 2>/dev/null
        "$_sus_bin" add_sus_path "$_target" 2>/dev/null
        "$_sus_bin" config sus_path add --loop "$_target" 2>/dev/null
    done
    "$_sus_bin" hide_sus_mnts_for_non_su_procs 1 2>/dev/null
    "$_sus_bin" config hide_sus_mnts_for_non_su_procs add 2>/dev/null
fi
MODDIR=${0%/*}
. "$MODDIR/zless/common.sh"

# Clean up any legacy soc0 mounts so /proc/self/mountinfo never leaks /data/adb paths to VDInfos
umount -l /sys/devices/soc0/soc_id 2>/dev/null
umount -l /sys/devices/soc0/machine 2>/dev/null
umount -l /proc/cpuinfo 2>/dev/null

check_license() {
    _d_bin="$MODDIR/bin/zlessd"
    if [ -x "$_d_bin" ]; then
        "$_d_bin" --check-license --moddir "$MODDIR" >/dev/null 2>&1 && return 0
    fi
    if [ -s /data/adb/zless/license.key ] || [ -s /data/adb/.zless_license.key ] || [ -s "$MODDIR/license.key" ]; then
        return 0
    fi
    return 1
}

if ! check_license; then
    exit 0
fi

# Universal Spoofer Engine (Nukes + Identity + TEE Sync + ADB Stealth)
[ -x "$MODDIR/zless/spoofer.sh" ] && "$MODDIR/zless/spoofer.sh" post-fs-data 2>/dev/null

[ "$(get_switch 权限加固)" = "开启" ] || exit 0

chmod 700 /mnt/vendor/persist/data 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/PRODUCT_INFO 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/WIFI 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/BT_Addr 2>/dev/null
chmod 660 /mnt/vendor/nvdata/APCFG/APRDEB/ETHERNET 2>/dev/null
# Directories retain search permission; only regular files are restricted.
for tree in /mnt/vendor/nvdata/md/NVRAM/NVD_IMEI /mnt/vendor/nvdata/md/NVRAM/CALIBRAT; do
    find "$tree" -type d -exec chmod 750 {} \; 2>/dev/null
    find "$tree" -type f -exec chmod 660 {} \; 2>/dev/null
done
